<?php
	$path="/var/www/html/Falcon Rover Crew Maseno University Scouts Club/inc/";
	require_once $path."db.php";
	
	function delete_event($conn, $newsId){
		if ($stmt = $conn -> prepare("DELETE FROM news WHERE newsId = ?")){
				$stmt -> bind_param('i',$newsId);
				$stmt -> execute();
				echo "<script> alert('Deleted successfully')</script>";
		}
	}
	
	if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete']) && !empty($_POST['delete'])){
		$deleteId = htmlspecialchars(trim($_POST['delete']), ENT_QUOTES,'UTF-8');
		if ($role === "ADMIN" && $admin === TRUE){
			delete_event($conn,$deleteId);
			unset($_POST['delete']);
		}
	}	
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta name="viewport" content="width=device-width ,initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title> FRCMSU News Feed page</title>
    <style>
    	.main{
            margin: auto;
            box-shadow: 0px 4px 4px 0px gray;
            padding: 50px;
            background: #ddd;
            width: 60%;
        }
    </style>
	</head>
	<body>
	<div class="main">

<?php
	if ($role === "ADMIN" && $admin === TRUE){
		echo '
			<h3>Add News Item</h3>
			<form action="add_news.php" method="post">
    				<input type="number" name="user-id" value="$userId" hidden>
    				<label for="title">Title:</label><br>
    				<input type="text" id="title" name="title"><br><br>
    				<label for="content">Content:</label><br>
    				<textarea id="content" name="content" rows="4" cols="50"></textarea><br><br>
    				<input type="submit" value="Add News">
			</form>
		';
	}
	
?>
<hr>

<h3>Newsfeed</h3>

<?php
	require_once $path."show_news.php";
?>
</div>
</body>
</html>
