<?php
	$path="/var/www/html/Falcon Rover Crew Maseno University Scouts Club/inc/";
	require_once $path."db.php";	

function manage_users($conn, $userId){
	echo "<div class='users'>";
	echo "<h3>Manage Users</h3>";
        	if ($stmt = $conn -> prepare("SELECT userId, name, email, rank, profile_picture FROM users WHERE userId <> ?")){
        		$stmt -> bind_param('i',$userId);
        		$stmt->execute();
        		$result = $stmt->get_result();

        		if ($result->num_rows > 0) {
        				echo "<div>";
                			echo "<button id='add-btn'> Add User </button>";
                			echo "</div>";
            			while ($row = $result->fetch_assoc()) {
            				$id = $row["userId"];
                			$name = $row["name"];
               				$email = $row['email'];
                			$rank = $row['rank'];
                			echo "<div>";
                			echo "<a href='./other_users.php?profile_name=$name&profile=$id'><p>$name</p></a>";
                			echo "<p>$email</p>";
                			echo "<p>$rank</p>";
                			echo "<button id='edit-btn' onclick=''> Edit </button>";
                			echo "<button onclick='test($id)'> Delete </button>";
                			echo "</div>";
                			echo "<hr>";
            			}
       			}else{
        			echo "<p>No users available</p>";
        		}
        	}
        	echo "</div>";
        	
}
  
function show_feedbacks($conn){      	
        	echo "<div class='feedback'>";
        	echo "<h3>Submitted Feedbacks</h3>";
        	if ($stmt = $conn -> prepare("SELECT f.feedbackId, f.feedback_text, f.submitted_at AS date, u.userId, u.name, u.email 
        			FROM feedback AS f INNER JOIN users AS u ON f.user_id = u.userId ORDER BY date")){
        			
        		$stmt->execute();
        		$result = $stmt->get_result();
        		if ($result->num_rows > 0) {
            			while ($row = $result->fetch_assoc()) {
            				$id = $row["userId"];
                			$name = $row["name"];
               				$email = $row['email'];
               				$date = $row['date'];
                			$feedback_text = $row['feedback_text'];
                			echo "<div>";
                			echo "<p>User: <a href='./other_users.php?profile_name=$name&profile=$id'>$name</a></p>";
                			echo "<p>Email: $email</p>";
                			echo "<p>Feedback: $feedback_text</p>";
                			echo "<p>Date: $date</p>";
                			echo "</div>";
                			echo "<hr>";
            			}
       			}else{
        			echo "<p>No feedback available</p>";
        		}
        	}
        	echo "</div>";
}

function show_rsvp($conn){
        	echo "<div class='rsvp'>";
        	echo "<h3>RSVP</h3>";
        	if ($stmt = $conn -> prepare("SELECT eventId, event_date,event_title,scheduled_time,event_venue, upload_time FROM events ")){
        		$stmt->execute();
        		
        		$result = $stmt->get_result();
        		if ($result->num_rows > 0) {
            			while ($row = $result->fetch_assoc()) {
            				$eventId = $row["eventId"];
            				$event_date = $row["event_date"];
            				$event_title = $row["event_title"];
            				$scheduled_time = $row["scheduled_time"];
            				$event_venue = $row["event_venue"];
            				$upload_date = $row["upload_time"];
                			echo "<div>";
                			echo "<p>{$event_date} - {$event_title} @ {$scheduled_time}, {$event_venue}</p>";
                			echo "<p>Upload date: $upload_date</p>";
                			echo "</div>";
                			$stmt = $conn->prepare("SELECT r.rsvp_status, r.event_id, r.rsvp_date, u.userId, u.name, u.email
                					FROM rsvp AS r INNER JOIN users AS u ON r.user_id = u.userId WHERE event_id = ? ORDER BY rsvp_date");
        				$stmt->bind_param("i", $eventId);
        				$stmt->execute();
        				$stmtResult = $stmt->get_result();
					echo "<p>Total rsvp: ".$stmtResult->num_rows."</p>";
        				if ($stmtResult->num_rows > 0) {
           					while ($stmtRow = $stmtResult->fetch_assoc()) {
                					$date = $stmtRow["rsvp_date"];
                					$eventId = $stmtRow['event_id'];
                					$rsvp_status = $stmtRow['rsvp_status'];
                					$id = $stmtRow["userId"];
                					$name = $stmtRow["name"];
               						$email = $stmtRow['email'];
               						echo "<div>";
                					echo "<p>User: <a href='./other_users.php?profile_name=$name&profile=$id'>$name</a></p>";
                					echo "<p>Email: $email</p>";
                					echo "<p>Status: $rsvp_status</p>";
                					echo "<p>Date: $date</p>";
                					echo "</div>";
               						echo "<hr>";
                				}
                			}else{
        					echo "<p>No RSVP available for this event</p>";
        				}
            			}
       			}else{
        			echo "<p>No Events available</p>";
        		}
        	}
        	echo "</div>";
}        	

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" content="width=device-width ,initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <title> FRCMSU Profile page</title>
    <style>
        body {
            background: white;
            padding: 40px;
            font-size: 14px;
        }
        .main{
            margin: auto;
            box-shadow: 0px 4px 4px 0px gray;
            padding: 50px;
            background: #ddd;
            width: 60%;
            border-radius: 10px;
        }
        
        .hidden {
  				display: none;
			}

			#container {
  				position: absolute;
  				top: 50%;
  				left: 50%;
  				transform: translate(-50%, -50%);
  				background-color: #f0f0f0;
  				padding: 20px;
  				border: 1px solid #ccc;
  				z-index: 5;
  				margin-top: 100px;
			}

			#innerContainer {
  				text-align: center;
			}

			#closeButton {
  				position: absolute;
  				top: 10px;
  				right: 10px;
  				background-color: transparent;
  				border: none;
  				cursor: pointer;
			}

      </style>
   </head>
   <body>
   	<div class="main">
   			<div id="container" class="hidden">
  				<div id="innerContainer">
    					<button id="closeButton">X</button>
    					<div id="container-contents">
    					</div>
    					<button id="cancelButton">Cancel</button>
  				</div>
  			</div>
  			<div>
  				<?php 
  					if ($role === "ADMIN" && $admin = TRUE){
  						if($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['action']) && !empty($_GET['action'])){
  							$action = htmlspecialchars(trim($_GET['action']), ENT_QUOTES,'UTF-8');
  							
  							if($action === "manage_users"){
  								manage_users($conn, $userId);
  							}elseif($action === "rsvp"){
  								show_rsvp($conn);
  							}elseif($action === "feedback"){
  								show_feedbacks($conn);
  							}else{
  								echo "argh";
  							}
  							
  						}
  					}else{
  						exit(header("Location: ./index.html"));
  					}
  				?>
  			</div>


</div>
</body>
<script>
	
	const add_btn = document.getElementById('add-btn');
  	const edit_btn = document.getElementById('edit-btn');
  	const del_btn = document.getElementById('del-btn');
 	const container = document.getElementById('container');
 	const closeButton = document.getElementById('closeButton');
  	const cancelButton = document.getElementById('cancelButton');
  	const container_contents = document.getElementById('container-contents');
  		
	document.addEventListener('DOMContentLoaded', function() {

  		add_btn.addEventListener('click', function(event) {
    			container.classList.remove('hidden');
    			container_contents.innerHTML = `
				<form action="./user_management.php" method="POST">
					<label for="name">Full Name: </label><br>
					<input type="text" name="name" id="name" required autofocus placeholder="e.g John Doe"/><br><br>
					<label for="email">Email: </label><br>
					<input type="email" name="email" id="email" placeholder="e.g johndoe@gmail.com"><br><br>
					<label for="phone-number">Phone Number: </label><br>
					<input type="tel" name="phone-number" id="phone-number" placeholder="e.g +254712345678" required/><br><br>
					<label for="dob">Date of Birth: </label><br>
					<input type="date" name="dob" id="dob" required/><br><br>
					<p>Gender</p>
					<input type="radio" name="gender" id="male" value="male" required/>
					<label for="male" class="radio-gender">Male: </label><br>
					<input type="radio" name="gender" id="female" value="female" required/>
					<label for="female" class="radio-gender">Female: </label><br>
					<input type="radio" name="gender" id="other" value="other" required/>
					<label for="other" class="radio-gender">Other: </label><br><br>
					<label for="card_number">Card Number: </label><br>
					<input type="text" name="card_number" id="card_number" required placeholder="Enter user's card number"/><br><br>
					<label for="rank">Rank: </label><br>
					<input type="text" name="rank" id="rank" required placeholder="Rank"/><br><br>
					<label for="payment_status">Payment_status: </label><br>
					<select name="payment_status" id="payment_status">
					<option value="NOT PAID" selected>NOT PAID</option>
					<option value="PAID">PAID</option>
					<option value="EXPIRED">EXPIRED</option>
					<option value="RENEWED">RENEWED</option>
					</select><br><br>
					<label for="role">Account role: </label><br>
					<select name="role" id="role">
					<option value="ADMIN">ADMIN</option>
					<option value="USER" selected>USER</option>
					</select><br><br>
					<label for="pass">Password: </label><br>
					<input type="password" name="pass" id="pass" placeholder="Enter password" required/><br><br>
					<label for="pass">Confirm Password: </label><br>
					<input type="password" name="confirm-pass" id="confirm-pass" placeholder="Confirm password" required/><br><br>
					<button type="submit">Submit</button><br><br>
				</form>
    				`;
    			event.stopPropagation();
  		});
  		edit_btn.addEventListener('click', function(event) {
    			container.classList.remove('hidden');
    			container_contents.innerHTML = `
    				<form action="update.php" method="post" enctype="multipart/form-data">
    					<label for="photo">Upload Photo:</label><br>
    					<input type="file" id="photo" name="photo"><br><br>
    					<input type="submit" value="Upload">
				</form>
    				`;
    			event.stopPropagation();
  		});
  		closeButton.addEventListener('click', function(event) {
    			container.classList.add('hidden');
    			event.stopPropagation();
  		});

  		cancelButton.addEventListener('click', function(event) {
    			container.classList.add('hidden');
    			event.stopPropagation();
  		});

  		document.addEventListener('click', function(event) {
    			if (!container.contains(event.target)) {
      				container.classList.add('hidden');
    			}
  		});
  		
  		
	});
	function test(user_id){
  		const accept = confirm("Confirm. Do you want to delete this account? ");
  		if(accept){
  			var xhr = new XMLHttpRequest();
  			var response = xhr.responseText;
  			
        		xhr.open('POST','./user_management.php');
        		xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        		xhr.onload = function (){
        			if(xhr.status === 200){
        				var response = xhr.responseText;
        				alert(response);
        				window.location.href = '<?php echo $_SERVER['PHP_SELF']; ?>';
               			}
        		};
       			xhr.send('user_id='+user_id);
  		}
    				
  	}
</script>
</html>
