<?php
// Database connection
$dbHost = "localhost";
$dbUser = "blvckai";
$dbPassword = "blvck953@#";
$dbName = "phplogin";
$conn = new mysqli($dbHost, $dbUser, $dbPassword, $dbName);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['photo_id']) && !empty($_POST['photo_id']) && isset($_POST['comment']) && !empty($_POST['comment'])) {
    $photoId = htmlspecialchars(trim($_POST['photo_id']), ENT_QUOTES,'UTF-8');
    $comment = htmlspecialchars(trim($_POST['comment']), ENT_QUOTES,'UTF-8');
    $userId = htmlspecialchars(trim($_POST['user_id']), ENT_QUOTES,'UTF-8');


    $insertStmt = $conn->prepare("INSERT INTO comments (photo_id, user_id, comment) VALUES (?, ?, ?)");
    $insertStmt->bind_param("iis", $photoId, $userId, $comment);
    $insertStmt->execute();


    if ($insertStmt->affected_rows > 0) {
    	$commentsStmt = $conn->prepare("SELECT users.name, comments.comment_date 
                                        FROM comments
                                        INNER JOIN users ON comments.user_id = users.userId
                                        WHERE comments.photo_id = ? AND comments.user_id = ? AND comments.comment = ?");
        $commentsStmt->bind_param("iis", $photoId, $userId, $comment);
	$commentsStmt->execute();
	$commentsStmt->store_result();
	$commentsStmt->bind_result($username,$date);
	$commentsStmt->fetch();
        echo "<div><p><strong>$username:</strong></p><p>$comment</p><span style='float:right'>$date</span></div>";
    } else {
        echo "Error adding comment.";
    }

    $insertStmt->close();
} else {
    echo "Invalid request.";
}

$conn->close();
?>
