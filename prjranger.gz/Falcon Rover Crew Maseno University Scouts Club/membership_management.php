<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process form submission

    // Validate form data (e.g., ensure required fields are filled)
    $errors = array();

    // Example validation for demonstration purposes
    if (empty($_POST["name"])) {
        $errors[] = "Name is required";
    }

    if (empty($_POST["email"])) {
        $errors[] = "Email is required";
    }

    // If no errors, process the form data
    if (empty($errors)) {
        // Process membership sign-up or renewal
        $name = $_POST["name"];
        $email = $_POST["email"];

        // For demonstration, just echo the submitted data
        echo "<p>Thank you, $name, for signing up/renewing your membership with us!</p>";
        echo "<p>Your email address: $email</p>";
        // You would typically save this data to a database
    } else {
        // If there are errors, display them
        echo "<ul>";
        foreach ($errors as $error) {
            echo "<li>$error</li>";
        }
        echo "</ul>";
    }
}
?>

<h3>Membership Management</h3>
<p>Join or renew your membership, and update your contact information:</p>
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
    <label for="name">Your Name:</label><br>
    <input type="text" id="name" name="name"><br><br>
    <label for="email">Your Email:</label><br>
    <input type="email" id="email" name="email"><br><br>
    <input type="submit" value="Submit">
</form>
