<?php
$server = 'localhost';
$username = 'blvckai';
$pass = 'blvck953@#';
$database='phplogin';

$conn = new mysqli($server,$username,$pass,$database);
if($conn -> connect_error){
	die("Connection Failed");
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['event-feedback']) && !empty($_POST['event-feedback'])&& isset($_POST['user-id']) && !empty($_POST['user-id'])){
    $feedback = htmlspecialchars(trim($_POST['event-feedback']), ENT_QUOTES,'UTF-8');
    $userId = htmlspecialchars(trim($_POST['user-id']), ENT_QUOTES,'UTF-8');
    // Example: store_feedback_in_database($feedback);
    if($smtp = $conn -> prepare('INSERT INTO feedback (user_id,feedback_text) VALUES (?,?)')){
	$smtp -> bind_param('is',$userId,$feedback);
	if( $smtp -> execute()){
		echo "Thank you for your feedback! ".$feedback;
	}
	else{
		echo "Error occurred: ".$smtp->error;
	}    
    }
    
} else {
    // Redirect or display an error message
    echo "Error: Invalid request method.";
}
?>
