







<?php 
	session_start();
	$DATABASE_HOST = 'localhost';
	$DATABASE_USER = 'blvckai';
	$DATABASE_PASS = 'blvck953@#';
	$DATABASE_NAME = 'phplogin';
	$conn = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
	if (mysqli_connect_errno()) {
		exit('Failed to connect to MySQL: ' . mysqli_connect_error());
	}

	if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['email']) && isset($_POST['card-number']) && isset($_POST['pass'])){
		if(!empty($_POST['email']) && !empty($_POST['card-number']) && !empty($_POST['pass'])){
			$email = htmlspecialchars(trim($_POST['email']), ENT_QUOTES,'UTF-8');
			$card_number = htmlspecialchars(trim($_POST['card-number']), ENT_QUOTES,'UTF-8');
			$pass = htmlspecialchars(trim($_POST['pass']), ENT_QUOTES,'UTF-8');
			
			if ($stmt = $conn -> prepare("SELECT userId,name, password FROM users WHERE email = ? AND card_number = ? ")){
				$stmt -> bind_param('ss',$email,$card_number);
				$stmt -> execute();
				$stmt -> store_result();
				if($stmt->num_rows > 0){
					$stmt -> bind_result($userId,$username, $password);
					$stmt -> fetch();
					if (password_verify($pass, $password)) {
						session_regenerate_id();
						$_SESSION['loggedin'] = TRUE;
						$_SESSION['name'] = $username;
						$_SESSION['id'] = $userId;
						header('Location: ./profile.php');
					} 
				}else{
					$stmt->close;
					$conn -> close;
					die("Invalid login details");
					
				}
				
				
			}else{
				$conn->close;
				die("Error occured while submiting the form try again");
			}
		}else{
			$conn->close;
			die("The form submitted was empty");	
		}
	
	}else{
		$conn->close;
		die("Please fill the form");
	}
?>
