






<?php
	$uploadDir = 'surveys/';
	
	if ($_SERVER['REQUEST_METHOD'] == 'POST'){
		if (isset($_FILES['survey_file']) && $_FILES['survey_file']['error'] == UPLOAD_ERR_OK){
			$fileName = $_FILES['survey_file']['name'];
			$fileSize = $_FILES['survey_file']['size'];
			$fileType = $_FILES['survey_file']['type'];
			$fileExtension = pathinfo($fileName,PATHINFO_EXTENSION);
			$fileTmpName = $_FILES['survey_file']['tmp_name'];
			
			$filepath = $uploadDir.basename($fileName);
			if(file_exists($filepath)){
				echo "A file with similar file name already exists";
				exit();
			}
			
			$allowedTypes = array('text/html','application/xhtml+html');
			$allowedExtensions = array('html','htm');
			if(!in_array($fileType, $allowedTypes) && !in_array(strtolower($fileExtension),$allowedExtensions)){
				echo "Error: only html files are allowed";
				exit();
			}
			
			if(move_uploaded_file($fileTmpName, $filepath)){
				header("Location: surveys_management.php");
				exit();
			}else{
				echo "Error uploading the file";
			}
		}else{
			echo "Error: ".$_FILES['survey_file']['error'];
		}
	}
?>
