<?php

$dbHost = "localhost";
$dbUser = "blvckai";
$dbPassword = "blvck953@#";
$dbName = "phplogin";
$conn = new mysqli($dbHost, $dbUser, $dbPassword, $dbName);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to retrieve messages for a specific user
function getMessages($userId, $conn) {
    $sql = "SELECT m.conversation_id, u1.name AS sender_name, m.sender_id, u2.name AS recipient_name, m.message_content, m.time 
            FROM messages m
            INNER JOIN users u1 ON m.sender_id = u1.userId
            INNER JOIN users u2 ON m.recipient_id = u2.userId
            WHERE m.sender_id = ? OR recipient_id = ?
            ORDER BY m.time DESC";
    
    
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("ii", $userId,$userId);
        $stmt->execute();
        $result = $stmt->get_result();
    	if ($stmt->error) {	
        	die("Failed to execute SQL statement: " . $stmt->error);
    	}else{	
    		$messages = array();
    		while ($row = $result->fetch_assoc()) {
    		
    			if($row['sender_id'] == $userId){
            			$conversationName = $row['conversation_id']."#".$row['recipient_name'];
            		}else{
            			$conversationName = $row['conversation_id']."#".$row['sender_name'];
            		}
            		
        		$messages[] = array(
        			"conversationId" => $conversationName,
            			"senderName" => $row['sender_name'],
            			"recipientName" => $row['recipient_name'],
            			"messageContent" => $row['message_content'],
            			"timestamp" => $row['time']
        		);
    		}
    	}
    	
    	$stmt->close();
    	return json_encode($messages);
        
    }else{
    	die("Failed to prepare SQL statement: " . $conn->error);
    }
}
function get_conversation_id($pdo,$usrId1){
	$stmt = $pdo -> prepare("SELECT conversation_id FROM conversations WHERE (user1_id = ? )");
	$stmt -> bind_param('i',$usrId1);
	$stmt -> execute();
	$stmt -> store_result();
	$stmt -> bind_result($conversation_id);
	$stmt -> fetch();
	return $conversation_id ? $conversation_id : null ;
} 


if (isset($_POST['user_id']) && !empty($_POST['user_id'])) {
    $userId = htmlspecialchars(trim($_POST['user_id']), ENT_QUOTES,'UTF-8');
    $messagesJson = getMessages($userId, $conn);    
    echo $messagesJson;
}else{
	echo "no data";
}

?>
