





<?php
	session_start();
	$DATABASE_HOST = 'localhost';
	$DATABASE_USER = 'blvckai';
	$DATABASE_PASS = 'blvck953@#';
	$DATABASE_NAME = 'phplogin';
	$conn = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
	if (mysqli_connect_errno()) {
		exit('Failed to connect to MySQL: ' . mysqli_connect_error());
	}
	
	if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['event-id']) && isset($_POST['userId']) && isset($_POST['rsvp-status'])){
		if(!empty($_POST['event-id']) && !empty($_POST['userId']) && !empty($_POST['rsvp-status'])){
			$event_id = htmlspecialchars(trim($_POST['event-id']), ENT_QUOTES,'UTF-8');
			$userId = htmlspecialchars(trim($_POST['userId']), ENT_QUOTES,'UTF-8');
			$rsvp_status = htmlspecialchars(trim($_POST['rsvp-status']), ENT_QUOTES,'UTF-8');
			
			
			if ($stmt = $conn -> prepare("SELECT rsvpId FROM rsvp WHERE event_id = ? AND user_id = ?")){
				$stmt -> bind_param('ii',$event_id,$userId);
				$stmt -> execute();
				$stmt -> store_result();
				if($stmt->num_rows > 0){
					if ($stmt = $conn -> prepare("UPDATE rsvp SET rsvp_status = ? WHERE event_id = ? AND user_id = ?")){
						$stmt -> bind_param('sii',$rsvp_status,$event_id,$userId);
						$stmt -> execute();
						echo "Changed successfully";
					}	
				}else{
					if ($stmt = $conn -> prepare("INSERT INTO rsvp (event_id,user_id,rsvp_status) VALUES (?,?,?)")){
						$stmt -> bind_param('iis',$event_id,$userId,$rsvp_status);
						$stmt -> execute();
						echo "Submitted successfully";
					}
				}
			}
		}else{
			echo "Please select the event and try again";
		}
	}
?>
