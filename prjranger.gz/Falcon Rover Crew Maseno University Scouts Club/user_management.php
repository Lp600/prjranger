<?php
	
	$path="/var/www/html/Falcon Rover Crew Maseno University Scouts Club/inc/";
	require_once $path."db.php";
	
	
	
	function delete_user($conn,$user_id){
		if($stmt = $conn -> prepare("DELETE FROM users WHERE userId = ?")){
			$stmt -> bind_param('i', $user_id);
			if($stmt -> execute()){
				echo "deleted successfully";
			}else{
				echo "Something occurred, try again";
			}
		}
		else{
			echo "Something occurred, try again";
		}
	}
	
	function add_user($conn, $name, $email, $card_number, $rank, $payment_status, $role, $phone_number, $dob, $gender, $password){
		if ($stmt = $conn->prepare('INSERT INTO users (name, email, card_number, rank, role, phone_number, 
						DOB, gender, payment_status, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')) {
			$password = password_hash($pass, PASSWORD_DEFAULT);
			$stmt->bind_param('ssisssssss', $name, $email, $card_number, $rank, $role, $phone_number, $dob, $gender, $payment_status, $password);
			if($stmt->execute()){
				echo "Account created successfully. ";
			}
		}
	}
	
	
	if($_SERVER['REQUEST_METHOD']==='POST'){
		
		if(isset($_POST['user_id']) && !empty($_POST['user_id'])){
			$user_id = htmlspecialchars(trim($_POST['user_id']), ENT_QUOTES,'UTF-8');
			delete_user($conn, $user_id);
			
		}elseif(isset($_POST['name']) && isset($_POST['email']) && isset($_POST['phone-number']) && isset($_POST['dob'])
		 && isset($_POST['gender']) && isset($_POST['pass']) && isset($_POST['card_number']) && isset($_POST['rank'])
		  && isset($_POST['payment_status']) && isset($_POST['role']) ){
	
			if(!empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['phone-number']) && !empty($_POST['dob'])
			 && !empty($_POST['gender']) && !empty($_POST['pass']) && !empty($_POST['card_number']) && !empty($_POST['rank']) 
			 && !empty($_POST['payment_status']) && !empty($_POST['role'])){
	  
				$name = htmlspecialchars(trim($_POST['name']), ENT_QUOTES,'UTF-8');
				$email = htmlspecialchars(trim($_POST['email']), ENT_QUOTES,'UTF-8');
				$phone_number = htmlspecialchars(trim($_POST['phone-number']), ENT_QUOTES,'UTF-8');
				$dob = htmlspecialchars(trim($_POST['dob']), ENT_QUOTES,'UTF-8');
				$gender = htmlspecialchars(trim($_POST['gender']), ENT_QUOTES,'UTF-8');
				$pass = htmlspecialchars(trim($_POST['pass']), ENT_QUOTES,'UTF-8');
				$card_number = htmlspecialchars(trim($_POST['card_number']), ENT_QUOTES,'UTF-8');
				$rank = htmlspecialchars(trim($_POST['rank']), ENT_QUOTES,'UTF-8');
				$payment_status = htmlspecialchars(trim($_POST['payment_status']), ENT_QUOTES,'UTF-8');
				$role = htmlspecialchars(trim($_POST['role']), ENT_QUOTES,'UTF-8');
				
				add_user($conn, $name, $email, $card_number, $rank, $payment_status, $role, $phone_number, $dob, $gender, $password);
			}else{
				echo "Fill in everything in the form";
			}
		}


	}else{
		echo "I'm not available";
	}
?>
