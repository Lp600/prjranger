
<?php

	$path="/var/www/html/Falcon Rover Crew Maseno University Scouts Club/inc/";
	require_once $path."db.php";
	
?>
<?php
	if($_SERVER['REQUEST_METHOD'] == "GET" && isset($_GET['profile_name']) && !empty($_GET['profile_name']) && isset($_GET['profile']) && !empty($_GET['profile']) ){	
		$profile_name = htmlspecialchars(trim($_GET['profile_name']),ENT_QUOTES,'UTF-8');
		$profile_id = htmlspecialchars(trim($_GET['profile']),ENT_QUOTES,'UTF-8');
	$username = '';
	$email = ''; 
	$rank = ''; 
	$profile_picture = '';
	function get_user($conn, $name, $id){
		if ($stmt = $conn -> prepare("SELECT name, email, rank, profile_picture FROM users WHERE name = ? AND userId = ? ")){
			$stmt -> bind_param('ss',$name,$id);
			$stmt -> execute();
			$stmt -> store_result();
			if($stmt->num_rows !== 1){
				header('Location: ./login.php');
				exit;
			}else{
				global $username;
				global $email; 
				global $rank; 
				global $profile_picture;
				$stmt -> bind_result($username,$email, $rank, $profile_picture );
				$stmt -> fetch();
				$path="/var/www/html/Falcon Rover Crew Maseno University Scouts Club/";
			}
		}
	}
	
		get_user($conn, $profile_name, $profile_id);
	}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" content="width=device-width ,initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title> FRCMSU Profile page</title>
    <style>
        body {
            background: white;
            padding: 40px;
            font-size: 14px;
        }
        .profile{
            margin: auto;
            display:table;
            box-shadow: 0px 4px 4px 0px gray;
            padding: 50px;
            background: #ddd;
            width: 60%;
        }
        .user-informations-container {
            margin: auto;
            display:table;
            width: 60%;
            margin-top:20px;
        }
   
        .user-informations{
        	margin: 20px;
        	margin: auto;
            	display:table;
        }
        .user-informations td:nth-child(1){
            font-weight: bold;
            padding: 5px 20px;
            width: 30%;
        }
        .user-informations td:nth-child(2){
            text-align: left;
            padding: 5px 20px 5px 40px;
            width: 50%;
        
        }
        
        .profile-pic{
            max-width: 10em;
            padding: 10px 30px;
            margin: auto;
            display:table;
        }
        
        section {
        	border: 1px solid black;
        	margin: 40px 20px;
        	padding: 20px 40px;
        }
    </style>
</head>

<body>
    <div class="profile">
        <img src="./uploads/profile_photos/<?php echo $profile_picture; ?>" alt="profile-picture" class="profile-pic">
        <div class="user-informations-container" >
            <table class="user-informations">
                <tr>
                    <td>Name: </td>
                    <td> <?php echo $username; ?></td>
                </tr>
                <tr>
                    <td>Email: </td>
                    <td> <?php echo $email; ?></td>
                </tr>
                <tr>
                    <td>Rank: </td>
                    <td><?php echo $rank; ?></td>
                </tr>
            </table>

        </div>
    </div>
    <section>
    	<div>
		<h4>Shared Photos </h4>
		
		<?php
// Retrieve shared_photos from the database
$sql = "SELECT shared_photos.photoId, shared_photos.filename, shared_photos.description, users.name 
        FROM shared_photos 
        INNER JOIN users ON shared_photos.uploader_id = users.userId WHERE shared_photos.uploader_id = ?";
$stmt = $conn->prepare($sql);
$stmt -> bind_param('i',$profile_id);
$stmt -> execute();
$result = $stmt -> get_result();


if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $photoId = $row["photoId"];
        $filename = $row["filename"];
        $description = $row["description"];
        $uploader = $row["name"];

        echo "<div style='padding:40px;margin:40px;border:2px solid black;'>";
        echo "<img src='uploads/$filename' alt='$description' style='width:200px;'>";
        echo "<p>Description: $description</p>";
        echo "<p>Uploaded by: $uploader</p>";

        $likesStmt = $conn->prepare("SELECT COUNT(*) AS like_count FROM likes WHERE photo_id = ?");
        $likesStmt->bind_param("i", $photoId);
        $likesStmt->execute();
        $likesResult = $likesStmt->get_result();
        $likeCount = $likesResult->fetch_assoc()["like_count"];
        $likesStmt->close();
        echo "<button style='margin:10px' onclick='likePhoto($photoId)'>Like</button><span id='like-count-$photoId'>$likeCount</span>";

        echo "<hr>";
        echo "<div>";
        echo "<h4>Comments</h4>";
        echo "<div id='comments-$photoId'>";


        $commentsStmt = $conn->prepare("SELECT users.name, comments.comment, comments.comment_date 
                                        FROM comments
                                        INNER JOIN users ON comments.user_id = users.userId
                                        WHERE comments.photo_id = ?
                                        ORDER BY comments.comment_date");
        $commentsStmt->bind_param("i", $photoId);
        $commentsStmt->execute();
        $commentsResult = $commentsStmt->get_result();

        if ($commentsResult->num_rows > 0) {
            while ($commentRow = $commentsResult->fetch_assoc()) {
                $username = $commentRow["name"];
                $comment = $commentRow["comment"];
                $date = $commentRow["comment_date"];
                echo "<div>";
                echo "<p><strong>$username:</strong> </p>";
                echo "<p>$comment</p>";
                echo "<span style='float:right'>$date</span>";
                echo "</div>";
            }
        }
        echo "</div>";

        echo "<div>";
        echo "<input type='text' name='comment' id='comment-$photoId' placeholder='Add a comment...'>";
        echo "<button type='submit' onclick='addComment($photoId, document.getElementById(\"comment-$photoId\").value)'>Post</button>";
        echo "</div>";
        echo "</div>";
        echo "</div>";
    }
} else {
    echo "No shared_photos found.";
}

$conn->close();
$js = "
        	<script>
        		function likePhoto(photoId){
        			var xhr = new XMLHttpRequest();
        			xhr.open('POST','like_photo.php');
        			xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        			xhr.onload = function (){
        				if(xhr.status === 200){
        					var likeCount = parseInt(xhr.responseText);
        					document.getElementById('like-count-'+photoId).innerText = likeCount;
        				}
        			};
        			xhr.send('user_id=' + $userId + '&photo_id='+photoId);
        		};
        		function addComment(photoId, comment){
        			var xhr = new XMLHttpRequest();
        			xhr.open('POST','add_comment.php');
        			xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        			xhr.onload = function (){
        				if(xhr.status === 200){
        					var newComment = '<div>'+xhr.responseText+'</div>';
        					//document.getElementById('comments-'+photoId).innerText += newComment;
        					var comments_container = document.getElementById('comments-'+photoId);
        					if(comments_container){
        						comments_container.innerHTML += newComment;
        					}
               				}
        			};
        			xhr.send('user_id=' + $userId + '&photo_id=' + photoId + '&comment=' + encodeURIComponent(comment));
        		};  
        	</script>
        ";
        echo $js;
?>

	</div>
    </section>
</body>
