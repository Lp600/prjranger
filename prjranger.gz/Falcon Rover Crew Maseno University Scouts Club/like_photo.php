<?php
// Database connection
$dbHost = "localhost";
$dbUser = "blvckai";
$dbPassword = "blvck953@#";
$dbName = "phplogin";
$conn = new mysqli($dbHost, $dbUser, $dbPassword, $dbName);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['photo_id']) && !empty($_POST['photo_id']) && isset($_POST['user_id']) && !empty($_POST['user_id'])) {
    $photoId = htmlspecialchars(trim($_POST['photo_id']), ENT_QUOTES,'UTF-8');
    $userId = htmlspecialchars(trim($_POST['user_id']), ENT_QUOTES,'UTF-8');

    $checkLikedStmt = $conn->prepare("SELECT COUNT(*) AS like_count FROM likes WHERE photo_id = ? AND user_id = ?");
    $checkLikedStmt->bind_param("ii", $photoId, $userId);
    $checkLikedStmt->execute();
    $checkLikedResult = $checkLikedStmt->get_result();
    $likeCount = $checkLikedResult->fetch_assoc()["like_count"];

    if ($likeCount == 0) {
        $insertStmt = $conn->prepare("INSERT INTO likes (photo_id, user_id) VALUES (?, ?)");
        $insertStmt->bind_param("ii", $photoId, $userId);
        $insertStmt->execute();

        if ($insertStmt->affected_rows > 0) {
            	$likesStmt = $conn->prepare("SELECT COUNT(*) AS like_count FROM likes WHERE photo_id = ?");
        	$likesStmt->bind_param("i", $photoId);
        	$likesStmt->execute();
        	$likesResult = $likesStmt->get_result();
        	$likeCount = $likesResult->fetch_assoc()["like_count"];
        	$likesStmt->close();
        	echo $likeCount;
        } else {
            echo "Error adding like.";
        }
    } else {
        $removeStmt = $conn->prepare("DELETE FROM likes WHERE photo_id = ? AND user_id = ?");
        $removeStmt->bind_param("ii", $photoId, $userId);
        $removeStmt->execute();
        if ($removeStmt->affected_rows > 0) {
            	$likesStmt = $conn->prepare("SELECT COUNT(*) AS like_count FROM likes WHERE photo_id = ?");
        	$likesStmt->bind_param("i", $photoId);
        	$likesStmt->execute();
        	$likesResult = $likesStmt->get_result();
        	$likeCount = $likesResult->fetch_assoc()["like_count"];
        	$likesStmt->close();
        	echo $likeCount;
        }
    }

    $checkLikedStmt->close();
    
    } else {
    echo "Invalid request.";
}

$conn->close();
?>
