






<?php 
	
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta name="viewport" content="width=device-width ,initial-scale=1.0">
    		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    		<title> FRCMSU Registration Page</title>
    		<style>
    			.main{
    				margin: auto;
            			box-shadow: 0px 4px 4px 0px gray;
            			padding: 50px;
            			background: #ddd;
            			width: 60%;
            			min-height: 80vh
    			}
    			.register-container{
    				width: 50%;
    				margin: auto;
    				text-align: left;
    				margin-top: 10%;
    				background: gray;
    				padding: 20px;
    				border-radius: 6px;
    				box-shadow: 0px 5px 5px 0px orange;
    			}
    			
    			.register-container input{
    				margin: 10px 0 20px 20px;
    				border-radius: 5px;
    				width: 80%;
    				height: 25px;
    				font-size: 1.0em;
    				padding: 2px 5px;
    			}
    			.register-container input:focus{
    				outline:none;
    				border:1px solid orange;
    			}
    			
    			.register-container label{
    				margin-left:20px;
    				color: white;
    				font-size: 1.1em;
    				font-weight: bolder;
    			}
    			.register-container button{
    				margin-left:20px;
    				width: 80px;
    				height: 25px;
    				font-size: 1.0em;
    				color: white;
    				background: black;
    				border: none;
    				font-weight:bold;
    				border-radius: 5px;
    			}
    			
    			.register-container button:hover{
    				color: black;
    				background: white;
    			}
    			
    			.register-container input[type=radio]{
    				text-align: left;
    				margin: 5px 20px;
    				display:inline-block;
    				width: 20px;
    			}
    			.register-container p {
    				margin-left:20px;
    				color: white;
    				font-size: 1.1em;
    				font-weight: bolder;
    			}
    		</style>
		
	</head>
	<body>
		<div class="main">
			<div class="register-container">
				<form action="./reg.php" method="POST">
					<label for="name">Full Name: </label><br>
					<input type="text" name="name" id="name" required autofocus placeholder="e.g John Doe"/><br>
					<label for="email">Email: </label><br>
					<input type="email" name="email" id="email" placeholder="e.g johndoe@gmail.com"><br>
					<label for="phone-number">Phone Number: </label><br>
					<input type="tel" name="phone-number" id="phone-number" placeholder="e.g +254712345678" required/><br>
					<label for="dob">Date of Birth: </label><br>
					<input type="date" name="dob" id="dob" required/><br>
					<p>Gender</p>
					<input type="radio" name="gender" id="male" value="male" required/>
					<label for="male" class="radio-gender">Male: </label><br>
					<input type="radio" name="gender" id="female" value="female" required/>
					<label for="female" class="radio-gender">Female: </label><br>
					<input type="radio" name="gender" id="other" value="other" required/>
					<label for="other" class="radio-gender">Other: </label><br><br>
					<label for="pass">Password: </label><br>
					<input type="password" name="pass" id="pass" placeholder="Enter password" required/><br>
					<label for="pass">Confirm Password: </label><br>
					<input type="password" name="confirm-pass" id="confirm-pass" placeholder="Confirm password" required/><br>
					<button type="submit">Submit</button>
				</form>
			</div>
		</div>
	</body>
</html>
