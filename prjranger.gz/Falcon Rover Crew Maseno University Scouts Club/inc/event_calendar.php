<?php
	
	
	if($stmt = $conn -> prepare("SELECT eventId,event_date,event_title,scheduled_time,event_venue FROM events")){
		$stmt -> execute();
		$eventsResult = $stmt->get_result();
		$events = array();
		if ($eventsResult->num_rows > 0) {
            		while ($eventsRow = $eventsResult->fetch_assoc()) {
            			$event = array(
            			"eventId" => $eventsRow['eventId'],"event_date" => $eventsRow['event_date'],
            			"event_title" => $eventsRow['event_title'],"scheduled_time" => $eventsRow['scheduled_time'],
            			"event_venue" => $eventsRow['event_venue']
            			);
            			$events[] = $event;	
            		} 
            	}
	
	}

// Display events
echo "<h3>Event Calendar</h3>";
echo "<ul>";
foreach ($events as $event) {
    echo "<li>{$event['event_date']} - {$event['event_title']} @ {$event['scheduled_time']}, {$event['event_venue']}</li>";
}
echo "</ul>";

if ($role === "ADMIN" && $admin = TRUE){
    		manage_events();
}

echo "<h4>Submit RSVP</h4>";
echo "<form action='rsvp.php' method='post'>";
echo "<input type='number' name='userId' value='$userId' hidden>";
echo "<label for='rsvp'>RSVP: </label>";
echo "<select id='rsvp' name='rsvp-status'>";
echo "<option value='ATTENDING' selected>Attending</option>";
echo "<option value='NOT ATTENDING'>Not Attending</option>";
echo "<option value='NOT SURE'>Not Sure</option>";
echo "</select>";
echo "<label for='event'>Event:</label>";
echo "<select id='event' name='event-id'>";
foreach ($events as $event) {
    	echo "<option value='{$event['eventId']}'>{$event['event_title']} @ {$event['event_date']}</option>";
}
echo "</select>";
echo "<input type='submit' value='Submit'>";
echo "</form>";


?>
