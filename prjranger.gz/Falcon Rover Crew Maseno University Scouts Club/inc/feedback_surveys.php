<h3>Feedback and Surveys</h3>

<p>Thank you for participating in our events and activities! Your feedback is valuable to us.</p>

<h4>Event Feedback</h4>
<form action="./submit_feedback.php" method="post">
    <input type="number" name="user-id" value="<?php echo $userId?>" hidden>
    <label for="event-feedback">Please provide your feedback on the recent event:</label><br>
    <textarea id="event-feedback" name="event-feedback" rows="5" cols="50" required></textarea><br>
    <input type="submit" value="Submit Feedback">
</form>

<h4>Surveys</h4>
<p>We would appreciate it if you could take a moment to fill out the following surveys:</p>
<ol>
    <?php
    	$surveyFiles = glob('surveys/*');
        foreach ($surveyFiles as $surveyFile) {
            $surveyName = pathinfo($surveyFile,PATHINFO_FILENAME);
            echo "<li><a href='$surveyFile'>$surveyName</a>";
        }
        
    	if ($role === "ADMIN" && $admin = TRUE){
    		manage_survey();
    	}
    ?>
</ol>
