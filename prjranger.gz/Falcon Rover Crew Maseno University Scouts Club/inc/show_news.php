<?php
	
	
	
	
	$stmt = $conn->prepare("SELECT users.name, news.newsId, news.title, news.content, news.upload_date 
                                        FROM news
                                        INNER JOIN users ON news.uploader_id = users.userId
                                        ORDER BY news.upload_date DESC");
        $stmt->execute();
        $newsResult = $stmt->get_result();

        if ($newsResult->num_rows > 0) {
            while ($newsRow = $newsResult->fetch_assoc()) {
                $username = $newsRow["name"];
                $title = $newsRow["title"];
                $newsId = $newsRow["newsId"];
                $comment = $newsRow["content"];
                $date = $newsRow["upload_date"];
                echo "<div>";
                echo "<p><strong>$username:</strong> </p>";
                echo "<p><strong>$title</strong> </p>";
                echo "<p>$comment</p>";
                echo "<span style='float:right'>$date</span>";
                
                if ($role === "ADMIN" && $admin === TRUE){
                	echo "<form action='' method='POST'>";
    			echo "<input type='number' name='delete' value='{$newsId}' hidden>";
    			echo "<button type='submit'>Delete</button>";
    			echo "</form>";
    		}			
                echo "</div>";
                echo "<br><hr>";
            }
        }else{
        	echo "<p>No Available news</p>";
        }
?>
