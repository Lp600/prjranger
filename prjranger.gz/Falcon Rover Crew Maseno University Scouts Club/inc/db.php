<?php
	session_start();
	if (!isset($_SESSION['loggedin'])) {
		header('Location: ./login.php');
		exit;
	}
	
	$DATABASE_HOST = 'localhost';
	$DATABASE_USER = 'blvckai';
	$DATABASE_PASS = 'blvck953@#';
	$DATABASE_NAME = 'phplogin';
	$conn = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
	if (mysqli_connect_errno()) {
		exit('Failed to connect to MySQL: ' . mysqli_connect_error());
	}
	
	if(htmlspecialchars(trim($_SESSION['loggedin']),ENT_QUOTES,'UTF-8')){
		$name = htmlspecialchars(trim($_SESSION['name']),ENT_QUOTES,'UTF-8');
		$id = htmlspecialchars(trim($_SESSION['id']),ENT_QUOTES,'UTF-8');
		if ($stmt = $conn -> prepare("SELECT userId, name, email, phone_number, card_number, rank, DOB, gender, bio, profile_picture, role
						 FROM users WHERE name = ? AND userId = ? ")){
			$stmt -> bind_param('ss',$name,$id);
			$stmt -> execute();
			$stmt -> store_result();
			if($stmt->num_rows !== 1){
				header('Location: ./login.php');
				exit;
			}else{
				$stmt -> bind_result($userId, $username, $email, $phone_number, $card_number, $rank, $dob, $gender, $bio, $profile_picture, $role);
				$stmt -> fetch();
				if($role === "ADMIN"){
					require_once $path."adm.php";
				}
			}
		}
	}
	
?>
