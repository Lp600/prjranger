
    <h2>Connect with Us on Social Media</h2>

    <h3>Follow us on:</h3>
    <ul>
        <li><a href="https://www.facebook.com/falconrovercrewmasenouniversity">Facebook</a></li>
        <li><a href="https://www.youtube.com/falconcrewmasenouniversity">YouTube</a></li>
    </ul>

    <h3>Share this page:</h3>
    <button onclick="shareOnFacebook()">Share on Facebook</button>
    <button onclick="shareOnTwitter()">Share on Twitter</button>

    <script>
        function shareOnFacebook() {
            window.open('https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(window.location.href), 'facebook-share-dialog', 'width=626,height=436');
        }

        function shareOnTwitter() {
            window.open('https://twitter.com/intent/tweet?url=' + encodeURIComponent(window.location.href), 'twitter-share-dialog', 'width=626,height=436');
        }
    </script>
