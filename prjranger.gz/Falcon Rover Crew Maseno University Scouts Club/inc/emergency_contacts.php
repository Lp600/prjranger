





<h3>Emergency Contacts</h3>

<p>In case of emergencies during club activities, please refer to the following contacts:</p>

<ul>
    <li><strong>Emergency Services:</strong> <a href="tel:911">911</a></li>
    <li><strong>Club Leader:</strong> <a href="tel:+254702778202">+254702778202</a> or <a href="tel:+254114946970">+254114946970</a></li>
</ul>

<p>Procedures for handling emergencies:</p>
<ol>
    <li>Remain calm and assess the situation.</li>
    <li>Call emergency services immediately if necessary.</li>
    <li>Notify the club leader and other members.</li>
</ol>
