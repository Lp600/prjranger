




<?php 
	$resourcesDir ="resources/";
	$resourcesFiles = glob($resourcesDir.'*');
	if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['resource_file']) ){
		if ($_FILES['resource_file']['error'] == UPLOAD_ERR_OK){
			$fileName = $_FILES['resource_file']['name'];
			$fileSize = $_FILES['resource_file']['size'];
			$fileType = $_FILES['resource_file']['type'];
			$fileExtension = pathinfo($fileName,PATHINFO_EXTENSION);
			$fileTmpName = $_FILES['resource_file']['tmp_name'];
			
			$filepath = $resourcesDir.basename($fileName);
			if(file_exists($filepath)){
				echo "A file with similar file name already exists";
			}
			
			$allowedExtensions = array('txt', 'docx', 'doc', 'pdf');
			if(!in_array(strtolower($fileExtension),$allowedExtensions)){
				echo "Error: only txt, docx, doc and pdf files are allowed";
			}
			
			if(move_uploaded_file($fileTmpName, $filepath)){
				echo "File uploaded successfully.";
				unset($_FILES['resource_file']);
				echo "
        				<script> window.location.href = '{$_SERVER['PHP_SELF']}';</script>
        			";
			}else{
				echo "Error uploading the file";
			}
		}else{
			echo "Error: ".$_FILES['resource_file']['error'];
		}
	}
	
	if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_resource_file'])) {
    		$resourceToDelete = $_POST['delete_resource_file'];
    		if (in_array($resourceToDelete, $resourcesFiles)) {
        		unlink($resourceToDelete);
        		unset($_POST['delete_resource_file']);
			echo "
        			<script> window.location.href = '{$_SERVER['PHP_SELF']}';</script>
        		";
        	}
        }

?>




<h3>Resource Library</h3>

<?php	
	echo "<ul>";
        foreach ($resourcesFiles as $resourcesFile) {
            $docname = pathinfo($resourcesFile,PATHINFO_FILENAME);
            $fullname = basename($resourcesFile);
            echo "<li><a href='download.php?file=$fullname'>$docname</a> ";
            
            if ($role === "ADMIN" && $admin = TRUE){
            	echo "	<form action='' method='post' style='display:inline;'>
                		<input type='hidden' name='delete_resource_file' value='$resourcesFile'>
                		<button type='submit'>Delete</button>
            		</form></li>";
            }else{
            	echo "</li>";
            }
        }
        echo "</ul>";
        if ($role === "ADMIN" && $admin = TRUE){
        	echo '
        		<h5>Upload Document:</h5>
    			<form action="" method="post" enctype="multipart/form-data">
        			<input type="file" name="resource_file" required accept=".txt, .docx, .doc, .pdf">
        			<button type="submit">Upload</button>
    			</form>
    		';
        }
?>
