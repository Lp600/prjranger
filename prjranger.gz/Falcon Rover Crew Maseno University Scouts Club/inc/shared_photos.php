
<?php

	$sql = "SELECT shared_photos.photoId, shared_photos.filename, shared_photos.description, users.name, shared_photos.upload_date 
        	FROM shared_photos 
        	INNER JOIN users ON shared_photos.uploader_id = users.userId ORDER BY shared_photos.upload_date DESC";
	$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $photoId = $row["photoId"];
        $filename = $row["filename"];
        $description = $row["description"];
        $uploader = $row["name"];
        $date = $row["upload_date"];

        echo "<div style='padding:40px;margin:40px;border:2px solid black;'>";
        echo "<img src='uploads/shared_photos/$filename' alt='$description' style='width:200px;'>";
        echo "<p>Description: $description</p>";
        echo "<p>Uploaded by: $uploader</p>";
        echo "<p>Time: $date</p>";
        if ($role === "ADMIN" && $admin === TRUE){
                echo "<form action='' method='POST'>";
    		echo "<input type='number' name='delete' value='{$photoId}' hidden>";
    		echo "<button type='submit'>Delete</button>";
   		echo "</form>";
    	}

        $likesStmt = $conn->prepare("SELECT COUNT(*) AS like_count FROM likes WHERE photo_id = ?");
        $likesStmt->bind_param("i", $photoId);
        $likesStmt->execute();
        $likesResult = $likesStmt->get_result();
        $likeCount = $likesResult->fetch_assoc()["like_count"];
        $likesStmt->close();
        echo "<button style='margin:10px' onclick='likePhoto($photoId)'>Like</button><span id='like-count-$photoId'>$likeCount</span>";

        echo "<hr>";
        echo "<div>";
        echo "<h4>Comments</h4>";
        echo "<div id='comments-$photoId'>";

        $commentsStmt = $conn->prepare("SELECT users.name, comments.comment, comments.comment_date 
                                        FROM comments
                                        INNER JOIN users ON comments.user_id = users.userId
                                        WHERE comments.photo_id = ?
                                        ORDER BY comments.comment_date");
        $commentsStmt->bind_param("i", $photoId);
        $commentsStmt->execute();
        $commentsResult = $commentsStmt->get_result();

        if ($commentsResult->num_rows > 0) {
            while ($commentRow = $commentsResult->fetch_assoc()) {
                $username = $commentRow["name"];
                $comment = $commentRow["comment"];
                $date = $commentRow["comment_date"];
                echo "<div>";
                echo "<p><strong>$username:</strong> </p>";
                echo "<p>$comment</p>";
                echo "<span style='float:right'>$date</span>";
                echo "</div>";
            }
        }
        echo "</div>";

        
        echo "<div>";
        echo "<input type='text' name='comment' id='comment-form-$photoId' placeholder='Add a comment...'>";
        echo "<button type='submit' onclick='addComment($photoId)'>Post</button>";
        echo "</div>";
        echo "</div>";
        echo "</div>";
    }
} else {
    echo "No shared photos found.";
}

$conn->close();
$js = "
        	<script>
        		function likePhoto(photoId){
        			var xhr = new XMLHttpRequest();
        			xhr.open('POST','like_photo.php');
        			xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        			xhr.onload = function (){
        				if(xhr.status === 200){
        					var likeCount = parseInt(xhr.responseText);
        					document.getElementById('like-count-'+photoId).innerText = likeCount;
        				}
        			};
        			xhr.send('user_id=' + $userId + '&photo_id='+photoId);
        		};
        		function addComment(photoId){
        			var xhr = new XMLHttpRequest();
        			xhr.open('POST','add_comment.php');
        			var comment_form = document.getElementById('comment-form-'+photoId);
        			comment = comment_form.value;
        			xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        			xhr.onload = function (){
        				if(xhr.status === 200){
        					var newComment = '<div>'+xhr.responseText+'</div>';
        					var comments_container = document.getElementById('comments-'+photoId);
        					if(comments_container){
        						comments_container.innerHTML += newComment;
        					}
               				}
        			};
        			xhr.send('user_id=' + $userId + '&photo_id=' + photoId + '&comment=' + encodeURIComponent(comment));
        		};  
        	</script>
        ";
        echo $js;
?>
