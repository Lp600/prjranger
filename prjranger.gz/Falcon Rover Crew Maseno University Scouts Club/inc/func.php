






<?php
	
	function list_users_all($conn, $myusrId){
		echo "<div class='users'>";
        	if ($stmt = $conn -> prepare("SELECT userId, name, email, rank, profile_picture FROM users WHERE userId <> ?")){
        		$stmt -> bind_param('i',$myusrId);
        		$stmt->execute();
        		$result = $stmt->get_result();

        		if ($result->num_rows > 0) {
            			while ($row = $result->fetch_assoc()) {
            				$id = $row["userId"];
                			$name = $row["name"];
               				$email = $row['email'];
                			$rank = $row['rank'];
                			echo "<div>";
                			echo "<a href='./other_users.php?profile_name=$name&profile=$id'><p>$name</p></a>";
                			echo "<p>$email</p>";
                			echo "<p>$rank</p>";
                			echo "</div>";
                			echo "<hr>";
            			}
       			}else{
        			echo "No users available";
        		}
        	}
        	echo "</div>";
        }
        
        function list_users_search($conn, $query){
		echo "<div class='users'>";
        	if ($stmt = $conn -> prepare("SELECT userId, name, email, rank, profile_picture FROM users WHERE name = ? LIKE email = ? OR rank = ?")){
        		$stmt -> bind_param('sss',$query,$query,$query);
        		$stmt->execute();
        		$result = $stmt->get_result();

        		if ($result->num_rows > 0) {
            			while ($row = $result->fetch_assoc()) {
            				$id = $row["userId"];
                			$name = $row["name"];
               				$email = $row['email'];
                			$rank = $row['rank'];
                			echo "<div>";
                			echo "<a href='./other_users.php?profile_name=$name&profile=$id'><p>$name</p></a>";
                			echo "<p>$email</p>";
                			echo "<p>$rank</p>";
                			echo "</div>";
                			echo "<hr>";
            			}
       			}else{
        			echo "No users available";
        		}
        	}
        	echo "</div>";
        }
        
        function get_recipient_id( $conn,  $conversation_id, $sender_id){
        	if($stmt = $conn -> prepare("SELECT user1_id,user2_id FROM conversations WHERE (user1_id = ? OR user2_id = ?) AND conversation_id = ?")){
        		$stmt -> bind_param('iii',$sender_id,$sender_id,$conversation_id);
        		$stmt -> execute();
        		$stmt -> store_result();
        		if($stmt -> num_rows > 0){
        			$stmt -> bind_result($user1_id,$user2_id);
        			$stmt -> fetch();
        			if($user1_id == $sender_id){
        				return $user2_id;
        			}else{
        				return $user1_id;
        			}
        		}
        	}
        }
        function get_name($conn, $user_id){
        	if($stmt = $conn -> prepare("SELECT name FROM users WHERE userId = ?")){
        		$stmt -> bind_param('i', $user_id);
        		$stmt -> execute();
        		$stmt -> store_result();
        		if($stmt -> num_rows > 0){
        			$stmt -> bind_result($name);
        			$stmt -> fetch();
        			return $name;
        		}
        		
        	}
        }
        	
       
?>
