
<?php

	$events = array();
	$stmt = $conn -> prepare("SELECT event_date,event_title,scheduled_time,event_venue FROM events");
		$stmt -> execute();
		$stmtResult = $stmt -> get_result();
		if ($stmtResult->num_rows > 0) {
            		while ($row = $stmtResult->fetch_assoc()) {				
				$events[] =  array($row["event_date"]." - ". $row["event_title"] ." @ ".$row["scheduled_time"].", ".$row["event_venue"],
				 "-0.003050,34.608059");
			}
		}
		
	echo  "
		<h1>Club Meeting Locations</h1>
    		<div>
        		<label for=\"eventSelect\">Select Event:</label>
        		<select id=\"eventSelect\">
            			<option value=\"\">Select an event</option> 
       		";
                foreach ($events as $event) {
                    echo "<option value='" . $event[1] . "'>" . $event[0] . "</option>";
                }
                
	echo "                
        		</select>
    		</div>
   		<div>
        		<button onclick=\"changeMapType('street')\">Street View</button>
        		<button onclick=\"changeMapType('satellite')\">Satellite View</button>
    		</div>
    		<div id=\"map\"></div>

    	<script>
        	var map = L.map('map').setView([-0.003050, 34.608059], 13); // Default coordinates for \"XJW5+J6G, Nyawita\"
        	var tileLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            		attribution: '&copy; <a href=\"https://www.openstreetmap.org/copyright\">OpenStreetMap</a> contributors'
        	}).addTo(map);

        	var meetingLocations = [
        	";
        		foreach ($events as $event) {
                		$location = explode(",",$event[1]);
            			echo "{ lat: {$location[0]}, lng: {$location[1]}, name: \"$event[0]\" },";
        		}
        		
 		echo "
  					];
        	meetingLocations.forEach(function(location) {
            		L.marker([location.lat, location.lng]).addTo(map)
                	.bindPopup(location.name);
        	});

        	function updateMapView(event) {
            		var selectedCoordinates = event.target.value.split(',');
            		map.setView([parseFloat(selectedCoordinates[0]), parseFloat(selectedCoordinates[1])], 13);
        	}

        	var eventSelect = document.getElementById('eventSelect');
        	eventSelect.addEventListener('change', updateMapView);

        	function changeMapType(type) {
            		if (type === 'street') {
                		tileLayer.setUrl('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png');
            		} else if (type === 'satellite') {
                		tileLayer.setUrl('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}');
            		}
        	}
    </script>
	";
?>
