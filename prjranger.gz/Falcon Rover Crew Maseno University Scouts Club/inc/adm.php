






<?php
	$admin = TRUE;
	function manage_events(){
		echo "<br><a href='./manage_events.php'><button>Manage Events</button></a><br>";
	}
	
	function manage_survey(){
		echo "<br><br><a href='./surveys_management.php'><button>Manage Surveys</button></a><br>";
	}
?>
