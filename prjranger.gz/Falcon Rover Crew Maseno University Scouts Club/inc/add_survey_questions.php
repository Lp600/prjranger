<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Survey Questions</title>
</head>
<body>
    <h4>Add Survey Questions</h4>

    <form id="survey-form" action="create_survey.php" method="post">
        <label for="survey-title">Survey Title:</label><br>
        <input type="text" id="survey-title" name="survey-title" required><br>

        <div id="questions-container">
            <!-- Question inputs will be dynamically added here -->
        </div>

        <button type="button" id="add-question-btn">Add Question</button><br><br>

        <input type="submit" value="Create Survey">
    </form>

    <script>
        let questionCount = 1;

        function addQuestion() {
            const container = document.getElementById('questions-container');

            const div = document.createElement('div');
            div.id = `question-container${questionCount}`;
            div.innerHTML = `
                <label for="question${questionCount}">Question ${questionCount}:</label><br>
                <input type="text" id="question${questionCount}" name="questions[]" required><br>
                <select id="question-type${questionCount}" name="question-types[]">
                    <option value="checkbox">Checkbox</option>
                    <option value="radio">Radio Button</option>
                    <!-- Add more option types as needed -->
                </select><br>
                <div id="options${questionCount}"></div>
                <button type="button" class="add-option-btn" data-question-id="${questionCount}">Add Option</button>
                <button type="button" class="delete-question-btn" data-question-id="${questionCount}">Delete Question</button>
                <br><br>
            `;
            container.appendChild(div);

            questionCount++;
            updateQuestionNumbers();
        }

        function addOption(questionId) {
            const optionsContainer = document.getElementById(`options${questionId}`);
            const questionTypeSelect = document.getElementById(`question-type${questionId}`);
            const questionType = questionTypeSelect ? questionTypeSelect.value : 'checkbox';

            if (optionsContainer) {
                const optionCount = optionsContainer.children.length + 1;
                const div = document.createElement('div');
                div.id = `option-container${questionId}-${optionCount}`;
                div.innerHTML = `
                    <label for="option${questionId}-${optionCount}">Option ${optionCount}:</label>
                    <input type="text" id="option${questionId}-${optionCount}" name="options[${questionId}][]" class="option-input" required>
                    <button type="button" class="delete-option-btn" data-question-id="${questionId}" data-option-id="${optionCount}">Delete Option</button>
                    <br>
                `;
                optionsContainer.appendChild(div);
            }
        }

        function updateQuestionNumbers() {
            const questionContainers = document.querySelectorAll('[id^="question-container"]');
            questionContainers.forEach((container, index) => {
                container.querySelector('label').textContent = `Question ${index + 1}:`;
                const questionId = container.id.split('question-container')[1];
                container.id = `question-container${index + 1}`;
                container.querySelector('.add-option-btn').setAttribute('data-question-id', index + 1);
                container.querySelector('.delete-question-btn').setAttribute('data-question-id', index + 1);
                container.querySelectorAll('[id^="option-container"]').forEach((optionContainer, optionIndex) => {
                    const optionId = optionContainer.id.split(`option-container${questionId}-`)[1];
                    optionContainer.id = `option-container${index + 1}-${optionId}`;
                    optionContainer.querySelector('label').textContent = `Option ${optionIndex + 1}:`;
                    optionContainer.querySelector('input[type="text"]').id = `option${index + 1}-${optionId}`;
                    optionContainer.querySelector('input[type="text"]').name = `options[${index + 1}][]`;
                    optionContainer.querySelector('button.delete-option-btn').setAttribute('data-question-id', index + 1);
                });
            });
        }

        document.getElementById('add-question-btn').addEventListener('click', addQuestion);

        document.addEventListener('click', function(event) {
            if (event.target.classList.contains('add-option-btn')) {
                const questionId = event.target.getAttribute('data-question-id');
                addOption(questionId);
            }
        });

        document.addEventListener('click', function(event) {
            if (event.target.classList.contains('delete-option-btn')) {
                const questionId = event.target.getAttribute('data-question-id');
                const optionId = event.target.getAttribute('data-option-id');
                const optionContainer = document.getElementById(`option-container${questionId}-${optionId}`);
                optionContainer.remove();
                updateQuestionNumbers();
            }
        });

        document.addEventListener('click', function(event) {
            if (event.target.classList.contains('delete-question-btn')) {
                const questionId = event.target.getAttribute('data-question-id');
                const questionContainer = document.getElementById(`question-container${questionId}`);
                questionContainer.remove();
                updateQuestionNumbers();
            }
        });
    </script>
</body>
</html>
