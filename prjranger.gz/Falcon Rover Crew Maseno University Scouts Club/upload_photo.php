<?php
	session_start();
	if (!isset($_SESSION['loggedin'])) {
		header('Location: ./login.php');
		exit;
	}
	
	$DATABASE_HOST = 'localhost';
	$DATABASE_USER = 'blvckai';
	$DATABASE_PASS = 'blvck953@#';
	$DATABASE_NAME = 'phplogin';
	$conn = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
	if (mysqli_connect_errno()) {
		exit('Failed to connect to MySQL: ' . mysqli_connect_error());
	}
	
	if(htmlspecialchars(trim($_SESSION['loggedin']),ENT_QUOTES,'UTF-8')){
		$name = htmlspecialchars(trim($_SESSION['name']),ENT_QUOTES,'UTF-8');
		$id = htmlspecialchars(trim($_SESSION['id']),ENT_QUOTES,'UTF-8');
		if ($stmt = $conn -> prepare("SELECT userId, name, email, card_number, rank, profile_picture, bio, role FROM users WHERE name = ? AND userId = ? ")){
			$stmt -> bind_param('ss',$name,$id);
			$stmt -> execute();
			$stmt -> store_result();
			if($stmt->num_rows !== 1){
				header('Location: ./login.php');
				exit;
			}else{
				$stmt -> bind_result($userId,$username,$email, $card_number, $rank, $profile_picture, $bio, $role );
				$stmt -> fetch();
				$path="/var/www/html/Falcon Rover Crew Maseno University Scouts Club/";
				if($role === "ADMIN"){
					require_once $path."adm.php";
				}
			}
		}
	}
	
?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_FILES["photo"]) && $_FILES["photo"]["error"] == 0) {
        $uploadDir = "uploads/shared_photos/";
        if(!is_dir($uploadDir)){
        	if(!mkdir($uploadDir,0777,true)){
        		echo "Error occured while uploading folder";
        	}
        }


        $filename = uniqid()."_".basename($_FILES["photo"]["name"]);
        $targetFilePath = $uploadDir.$filename;

        if ($_FILES["photo"]["size"] > 10 * 1024 * 1024) {
            echo "Sorry, your file is too large.";
            exit;
        }

        $allowedFormats = array("jpg", "jpeg", "png", "gif");
        $fileFormat = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));
        if (!in_array($fileFormat, $allowedFormats)) {
            echo "Sorry, only JPG, JPEG, PNG, and GIF files are allowed.";
            exit;
        }

        if (move_uploaded_file($_FILES["photo"]["tmp_name"], $targetFilePath)) {
            $description = $_POST["description"];
            $uploaderId = $userId;

            $stmt = $conn->prepare("INSERT INTO shared_photos (filename, description, uploader_id) VALUES (?, ?, ?)");
            $stmt->bind_param("ssi", $filename, $description, $uploaderId);

            if ($stmt->execute()) {
                echo "File uploaded successfully.";
            } else {
                echo "Error: " . $stmt->error;
            }

            $stmt->close();
            $conn->close();
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    } else {
        echo "No file uploaded or an error occurred.";
    }
}
?>
