

<?php
	session_start();
	$DATABASE_HOST = 'localhost';
	$DATABASE_USER = 'blvckai';
	$DATABASE_PASS = 'blvck953@#';
	$DATABASE_NAME = 'phplogin';
	$conn = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
	if (mysqli_connect_errno()) {
		exit('Failed to connect to MySQL: ' . mysqli_connect_error());
	}

?>


<?php 

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['name']) && isset($_POST['email']) && isset($_POST['phone-number'])
	&& isset($_POST['dob']) && isset($_POST['gender']) && isset($_POST['pass'])){
	
	if(!empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['phone-number'])
	  && !empty($_POST['dob']) && !empty($_POST['gender']) && !empty($_POST['pass'])){
	  
		$name = htmlspecialchars(trim($_POST['name']), ENT_QUOTES,'UTF-8');
		$email = htmlspecialchars(trim($_POST['email']), ENT_QUOTES,'UTF-8');
		$phone_number = htmlspecialchars(trim($_POST['phone-number']), ENT_QUOTES,'UTF-8');
		$dob = htmlspecialchars(trim($_POST['dob']), ENT_QUOTES,'UTF-8');
		$gender = htmlspecialchars(trim($_POST['gender']), ENT_QUOTES,'UTF-8');
		$pass = htmlspecialchars(trim($_POST['pass']), ENT_QUOTES,'UTF-8');
	}else{
		echo "Fill in everything in the form";
	}
}else{
	echo "Fill in everything in the form";
}

if ($stmt = $conn->prepare('SELECT id FROM accounts WHERE email = ?')) {
	$stmt->bind_param('s', $email);
	$stmt->execute();
	$stmt->store_result();
	if ($stmt->num_rows > 0) {
		header("Location: ./register.php?error=7");
		$stmt->close();
		exit();
	}else{
		// Username and email doesn't exists, inserting new account
		if ($stmt = $conn->prepare('INSERT INTO users (name, email, card_number, rank, role, phone_number, 
						DOB, gender, payment_status, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')) {
			
			$password = password_hash($pass, PASSWORD_DEFAULT);
			$card_no = 12345678;
			$rank = 'Scout';
			$role = 'USER';
			$payment_status = 'NOT PAID';
			
			
			$stmt->bind_param('ssisssssss',$name, $email, $card_no, $rank, $role, $phone_number, $dob, $gender, $payment_status, $password);
			$stmt->execute();
			if ($stmt = $conn->prepare('SELECT userId FROM users WHERE email = ?')) {
				$stmt->bind_param('s', $email);
				$stmt->execute();
				$stmt->store_result();
				$stmt->bind_result($id);
				$stmt->fetch();
				session_regenerate_id();
				$_SESSION['loggedin'] = TRUE;
				$_SESSION['name'] = $name;
				$_SESSION['id'] = $id;
				header('Location: ./profile.php');
			}
		} else {
			header("Header: ./register.php?error=8");
			$conn->close();
			exit();
		}
	}
	$stmt->close();
} else {
	header("Header: ./register.php?error=8");
	$conn->close();
	exit();
}
$con->close();



?>
