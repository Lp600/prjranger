





<?php
	$dbHost = "localhost";
	$dbUser = "blvckai";
	$dbPassword = "blvck953@#";
	$dbName = "phplogin";
	$conn = new mysqli($dbHost, $dbUser, $dbPassword, $dbName);
	if ($conn->connect_error) {
    		die("Connection failed: " . $conn->connect_error);
	}
	
	if (isset($_POST['senderId']) && isset($_POST['recipientId']) && isset($_POST['messageContent'])) {
		if(!empty($_POST['senderId']) && !empty($_POST['recipientId']) && !empty($_POST['messageContent'])){
			$senderId = htmlspecialchars(trim($_POST['senderId']), ENT_QUOTES,'UTF-8');
			$recipientId = htmlspecialchars(trim($_POST['recipientId']), ENT_QUOTES,'UTF-8');
			$msgcontent = htmlspecialchars(trim($_POST['messageContent']), ENT_QUOTES,'UTF-8');
		}else{
			die ("Message cannot be empty");
		}
	
	
		$conversation_id = get_conversation_id($conn,$senderId, $recipientId);
		if(!$conversation_id){
			$conversation_id = generate_conversation_id($senderId, $recipientId);
			$stmt = $conn -> prepare("INSERT INTO conversations (conversation_id,user1_id,user2_id) VALUES(?, ?, ?)");
			$stmt -> bind_param('sii',$conversation_id, $senderId, $recipientId);
			$stmt -> execute();
		}
	
		if($stmt = $conn -> prepare("INSERT INTO messages (conversation_id,sender_id,recipient_id,message_content) VALUES(?, ?, ?, ?)")){
			$stmt -> bind_param('siis',$conversation_id, $senderId, $recipientId, $msgcontent);
			$stmt -> execute();
		}
	}
	
	function get_conversation_id($pdo,$usrId1, $usrId2){
		$stmt = $pdo -> prepare("SELECT conversation_id FROM conversations WHERE (user1_id = ? AND user2_id = ? ) OR (user1_id = ? AND user2_id = ? )");
		$stmt -> bind_param('iiii',$usrId1, $usrId2, $usrId2, $usrId1);
		$stmt -> execute();
		$stmt -> store_result();
		$stmt -> bind_result($conversation_id);
		$stmt -> fetch();
		return $conversation_id ? $conversation_id : null ;
	} 
	
	
	function generate_conversation_id($userId1, $userId2){
		$sorted = [$userId1,$userId2];
		sort($sorted);
		$combinedIds = implode('-',$sorted).'-'.time();
		return $combinedIds;
	}
?>
