






<?php 
	
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta name="viewport" content="width=device-width ,initial-scale=1.0">
    		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    		<title> FRCMSU Login Page</title>
    		<style>
    			.main{
    				margin: auto;
            			box-shadow: 0px 4px 4px 0px gray;
            			padding: 50px;
            			background: #ddd;
            			width: 60%;
            			min-height: 80vh
    			}
    			.login-container{
    				width: 50%;
    				margin: auto;
    				text-align: left;
    				margin-top: 10%;
    				background: gray;
    				padding: 20px;
    				border-radius: 6px;
    				box-shadow: 0px 5px 5px 0px orange;
    			}
    			
    			.login-container input{
    				margin: 10px 0 20px 20px;
    				border-radius: 5px;
    				width: 80%;
    				height: 25px;
    				font-size: 1.0em;
    				padding: 2px 5px;
    			}
    			.login-container input:focus{
    				outline:none;
    				border:1px solid orange;
    			}
    			
    			.login-container label{
    				margin-left:20px;
    				color: white;
    				font-size: 1.1em;
    				font-weight: bolder;
    			}
    			.login-container button{
    				margin-left:20px;
    				width: 80px;
    				height: 25px;
    				font-size: 1.0em;
    				color: white;
    				background: black;
    				border: none;
    				font-weight:bold;
    				border-radius: 5px;
    			}
    			
    			.login-container button:hover{
    				color: black;
    				background: white;
    			}
    		</style>
		
	</head>
	<body>
		<div class="main">
			<div class="login-container">
				<form action="./auth.php" method="POST">
					<label for="email">Email: </label><br>
					<input type="email" name="email" id="email" placeholder="Enter your email" required autofocus><br>
					<label for="card_number">Card Number: </label><br>
					<input type="text" name="card-number" id="card-number" placeholder="Enter membership card number" required/><br>
					<label for="pass">Password: </label><br>
					<input type="password" name="pass" id="pass" placeholder="Enter password" required/><br>
					<button type="submit">Submit</button>
				</form>
			</div>
		</div>
	</body>
</html>
