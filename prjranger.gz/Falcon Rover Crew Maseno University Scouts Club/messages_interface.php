<?php
	$path="/var/www/html/Falcon Rover Crew Maseno University Scouts Club/inc/";
	require_once $path."db.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Message Interface</title>
<style>
  body{
  	padding: 10px 40px;
  }
  .messages{
  	border: 2px solid green;
  	display:flex;
  	flex-direction:row;
  	height: 95vh;
  }
  #home-ui{
  	width : 30%;
  	padding: 20px;
  	
  }
  #conversation-list {
  	list-style:none;
  }
   #conversation-list li{
   	cursor:pointer;
   	margin: 20px 0px;
   }
  #message-container{
  	width : 70%;
  	padding: 10px;
  	max-height: 100%;
  	overflow-y: auto;
  	border: 1px solid black;
  }
  .sender-message{
  	background:gray;
  	text-align: right;
  	padding: 30px;
  	border-radius: 10px;
  	margin: 20px;
  	overflow-x: auto;
  	width:80%;
  	float: none;
  	
  }
  
  .sender-message p{
  	word-break: break-word;
  }
  .recipient-message{
  	padding: 30px;
  	background:#dddddd;
  	text-align: left;
  	padding: 30px;
  	border-radius: 10px;
  	width: 80%;
  	float:none;
  	margin: 20px;
  	overflow-x: auto;
  }
  
  .recipient-message p{
  	word-break: break-word;
  }
  .message-input{
  	display:flex;
  	flex-direction:row;
  }
  .message-input input{
  	width:95%;
  	height:40px;
  }
  .message-input button{
  	width:5%;
  	height:40px;
  }
  
        .hidden {
  display: none;
}

#container {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: #f0f0f0;
  padding: 20px;
  border: 1px solid #ccc;
}

#innerContainer {
  text-align: center;
}

#closeButton {
  position: absolute;
  top: 10px;
  right: 10px;
  background-color: transparent;
  border: none;
  cursor: pointer;
}

</style>
</head>
<body>
<div class="messages">
<div id="home-ui">
  <h3>Conversations</h3>
  <ul id="conversation-list">

  </ul>
  
</div>

<div id="message-container">
  <!-- Messages for selected conversation will be displayed here -->
</div>
</div>
<script>
let messages = [];
let converId = '';
// Function to retrieve initial data in JSON format from the server
function retrieveInitialData() {
  const xhr = new XMLHttpRequest();
  xhr.open("POST", "message_db.php", true);
  xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
      messages = JSON.parse(xhr.responseText);
      populateConversationList();
      // Start polling for new messages
      setInterval(checkForNewMessages, 10000);
    }
  };
  xhr.send('user_id=' + <?php echo $userId; ?>);
}

// Function to display messages for a conversation
function displayConversationMessages(conversationId) {
  const messageContainer = document.getElementById('message-container');
  messageContainer.innerHTML = ''; // Clear previous messages

  // Filter messages for the selected conversation and sort by timestamp
  const conversationMessages = messages.filter(message => message.conversationId === conversationId)
                                         .sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));

  // Display messages in left-right format
  conversationMessages.forEach(message => {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message');
    messageDiv.classList.add(message.senderName === '<?php echo $username; ?>' ? 'sender-message' : 'recipient-message');
    messageDiv.innerHTML = `
      <p><strong>From:</strong> ${message.senderName}</p>
      <p><strong>To:</strong> ${message.recipientName}</p>
      <p><strong>Message:</strong> ${message.messageContent}</p>
      <p><strong>Timestamp:</strong> ${message.timestamp}</p>
    `;
    messageContainer.appendChild(messageDiv);
  });
  const messageInput = document.createElement('div');
    messageInput.classList.add('message-input');
    messageInput.innerHTML = `
      <input type="text" id="message-content-${conversationId}" placeholder="Type your message...">
      <button id="send-button-${conversationId}">Send</button>
    `;
    messageInput.querySelector(`#send-button-${conversationId}`).addEventListener('click', () => {
      sendMessage(conversationId);
    });
    converId=`${conversationId}`;

    messageContainer.appendChild(messageInput);
    messageContainer.scrollTop = messageContainer.scrollHeight;
}

// Function to populate conversation list
function populateConversationList() {
  const conversationList = document.getElementById('conversation-list');
  conversationList.innerHTML = ''; // Clear previous conversation list
  const conversations = [...new Set(messages.map(message => message.conversationId))]; // Get unique conversation IDs

  // Sort conversations by latest message timestamp
  conversations.sort((a, b) => {
    const latestMessageA = messages.filter(message => message.conversationId === a)
                                   .sort((x, y) => new Date(y.timestamp) - new Date(x.timestamp))[0];
    const latestMessageB = messages.filter(message => message.conversationId === b)
                                   .sort((x, y) => new Date(y.timestamp) - new Date(x.timestamp))[0];
    return new Date(latestMessageB.timestamp) - new Date(latestMessageA.timestamp);
  });

  conversations.forEach(conversationId => {
    const listItem = document.createElement('li');
    
    listItem.addEventListener('click', () => {
      displayConversationMessages(conversationId);
    });

    listItem.textContent = conversationId.split('#')[1];
    conversationList.appendChild(listItem);
    
  });
}

// Function to find newly added rows
function findNewRows(oldArray, newArray) {
  const newRows = [];
  for (const newObj of newArray) {
    let found = false;
    for (const oldObj of oldArray) {
      if (JSON.stringify(oldObj) === JSON.stringify(newObj)) {
        found = true;
        break;
      }
    }
    if (!found) {
      newRows.push(newObj);
    }
  }
  return newRows;
}

// Function to check for new messages
function checkForNewMessages() {
  const xhr = new XMLHttpRequest();
  xhr.open("POST", "message_db.php", true);
  xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
  xhr.onreadystatechange = function () {
  /*
    if (xhr.readyState === 4 && xhr.status === 200) {
     
      const newMessages = JSON.parse(xhr.responseText);
      messages.push(newMessage);
      if (newMessages.length > 0) {
        // Update the messages array with new messages
        messages = messages.concat(newMessages);
        // Refresh conversation display
        // For simplicity, you can refresh the entire conversation list
        //populateConversationList();
      }
    }*/
    if (xhr.readyState === 4 && xhr.status === 200) {
    	const newMessages = JSON.parse(xhr.responseText);
    	if (newMessages.length > 0) {
    		var newtexts = findNewRows(messages, newMessages);
    		messages = messages.concat(newtexts);
    		
    		if(newtexts){
    			
    			newtexts.forEach(row => {
    				messages.push(JSON.stringify(row, null, 2));
			});
			//populateConversationList(conversationId);
			//displayConversationMessages(converId);
    		}
    	}
    	
    }
    
  };
  xhr.send('user_id=' + <?php echo $userId; ?>);
}

// Function to send a message
function sendMessage(conversationId) {
  const messageContent = document.getElementById(`message-content-${conversationId}`).value;
  const senderName = "<?php echo $username; ?>"; // Get sender name from somewhere
  const recipientName = "adm"; // Get recipient name from somewhere
  const timestamp = new Date().toISOString();

  const newMessage = {
    "conversationId": conversationId,
    "senderName": senderName,
    "recipientName": recipientName,
    "messageContent": messageContent,
    "timestamp": timestamp
  };

  // Send the message to the server  
  var xhr = new XMLHttpRequest();
  xhr.open('POST','store_messages.php');
  xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
  xhr.onload = function (){
  	if(xhr.status === 200){
  		messages.push(newMessage);
      		displayConversationMessages(conversationId);
       	}
   };
   xhr.send('senderId=' + <?php echo $userId; ?> + '&recipientId=' + 3 + '&messageContent=' + encodeURIComponent(messageContent));
}

// Populate conversation list and retrieve initial data on page load
window.onload = function() {
  retrieveInitialData();
};
/*
function get_recipient(conversationId , callback){
  return new Promise((resolve,reject) => {
  var xhr = new XMLHttpRequest();
  xhr.open('POST','func.php');
  xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
  xhr.onload = function (){
  	if(xhr.status === 200){
  		const conver_name = xhr.responseText;
  		resolve(conver_name);
       	}else{
       		reject("Error");
       	}
   };
   xhr.send('user_id=' + <?php echo $userId; ?> + '&conversation_id=' +  conversationId);
   });
}
*/
</script>
</body>
</html>
