








<?php
	$path="/var/www/html/Falcon Rover Crew Maseno University Scouts Club/inc/";
	require_once $path."db.php";	
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta name="viewport" content="width=device-width ,initial-scale=1.0">
    		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    		<title> FRCMSU Edit Profile page</title>
    		<style>
    			.main{
            			margin: auto;
            			box-shadow: 0px 4px 4px 0px gray;
            			padding: 50px;
            			background: #ddd;
            			width: 60%;
        		}
    			.edit-picture-container{
    				width: 10em;
    				display:table;
    				margin: auto;
    				border: 1px solid black;
    				margin-top: 4em;
    			}
    			.edit-profile {
    				display:table;
    				margin: 3em auto;
    				width: 60%;
    			}
    			.profile-pic{
    				width: 90%;
    			}
    			
    			.edit-picture{
    				position:relative;
    				left:0;
    				bottom:0;
    				float:right;
    				background:none;
    				border:none;
    			}
    			.edit-picture:hover{
    				cursor: pointer;
    			}
    			   			
			.hidden {
  				display: none;
			}

			#container {
  				position: absolute;
  				top: 50%;
  				left: 50%;
  				transform: translate(-50%, -50%);
  				background-color: #f0f0f0;
  				padding: 20px;
  				border: 1px solid #ccc;
  				z-index: 5;
			}

			#innerContainer {
  				text-align: center;
			}

			#closeButton {
  				position: absolute;
  				top: 10px;
  				right: 10px;
  				background-color: transparent;
  				border: none;
  				cursor: pointer;
			}

    		</style>
	</head>
	<body>
		<div class="main">
			<div>
				<div class="edit-picture-container">
					<img src="./uploads/profile_photos/<?php echo $profile_picture; ?>" alt="profile-picture" class="profile-pic">
					<button class="edit-picture" id="edit-picture-btn"><i class="fas fa-edit"></i></button>
				</div>
			</div>
			<div id="container" class="hidden">
  				<div id="innerContainer">
    					<button id="closeButton">X</button>
    					<div id="container-contents">
    					</div>
    					<button id="cancelButton">Cancel</button>
  				</div>
  			</div>
			<div>
				<table class="edit-profile">
					<tr>
						<th>Details</th><th>Value</th><th>Action</th>
					</tr>
					<tr>
						<td>Full Name: </td><td><?php echo $username; ?></td><td></td>
					</tr>
					<tr>
						<td>Email: </td><td><?php echo $email; ?></td><td></td>
					</tr>
					<tr>
						<td>Phone Number: </td><td><?php echo $phone_number; ?></td><td></td>
					</tr>
					<tr>
						<td>Card Number: </td><td><?php echo $card_number; ?></td><td></td>
					</tr>
					<tr>
						<td>Rank: </td><td><?php echo $rank; ?></td><td></td>
					</tr>
					<tr>
						<td>DoB: </td><td><?php echo $dob; ?></td><td></td>
					</tr>
					<tr>
						<td>Gender: </td><td><?php echo $gender; ?></td><td></td>
					</tr>
					<tr>
						<td>Bio: </td><td><?php echo $bio; ?></td><td></td>
					</tr>
					<tr>
						<td>Password: </td><td>*-*-*-*-*-*-*-*</td><td><button id="ch-passwd-btn">Change Password</button></td>
					</tr>
					<tr>
						<td colspan="3"><button id="edit-profile-btn"><i class="fas fa-edit"></i> Edit</button></td>
					</tr>
				</table>
			</div>

			<section>
				<h3>Activities</h3>
				<div id='rsvp'>
					<h4> RSVP </h4>
					<?php
        					$stmt = $conn->prepare("SELECT rsvp_status, event_id, rsvp_date FROM rsvp 
        								WHERE user_id = ? ORDER BY rsvp_date");
        					$stmt->bind_param("i", $userId);
        					$stmt->execute();
        					$stmtResult = $stmt->get_result();
	
        					if ($stmtResult->num_rows > 0) {
            						while ($stmtRow = $stmtResult->fetch_assoc()) {
                						$date = $stmtRow["rsvp_date"];
                						$eventId = $stmtRow['event_id'];
                						$rsvp_status = $stmtRow['rsvp_status'];
                						$stmt = $conn -> prepare("SELECT event_date,event_title,scheduled_time,event_venue 
                									FROM events WHERE eventId = ?");
                						$stmt->bind_param("i", $eventId);
								$stmt -> execute();
								$stmt -> store_result();
								$stmt -> bind_result($event_date ,$event_title, $scheduled_time, $event_venue);
								$stmt -> fetch(); 
                						echo "<div>";
                						echo "<p>{$event_date} - {$event_title} @ {$scheduled_time}, {$event_venue}</p>";
                						echo "<p>RSVP status: $rsvp_status </p>";
                						echo "<span>$date</span>";
                						echo "</div>";
            						}
        					}else{
        						echo "No activities for this yet";
        					}
        			?>
				</div>
				<div id='comments'>
					<h4> Comments </h4>
					<?php
	
        					$commentsStmt = $conn->prepare("SELECT comments.photo_id, comments.comment, comments.comment_date 
                	                        				FROM comments
                	                        				INNER JOIN users ON comments.user_id = users.userId 
                	                        				WHERE comments.user_id = ?
                	                        				ORDER BY comments.comment_date");
        					$commentsStmt->bind_param("i", $userId);
        					$commentsStmt->execute();
        					$commentsResult = $commentsStmt->get_result();
	
        					if ($commentsResult->num_rows > 0) {
            						while ($commentRow = $commentsResult->fetch_assoc()) {
                						$comment = $commentRow["comment"];
                						$date = $commentRow["comment_date"];
                						$photoId = $commentRow['photo_id'];
                						$stmt = $conn->prepare("SELECT filename,description FROM shared_photos WHERE photoId = ?");
                						$stmt -> bind_param('i',$photoId);
                						$stmt -> execute();
                						$stmt -> store_result();
                						$stmt -> bind_result($imgSrc,$description);
                						$stmt -> fetch();
                						echo "<div>";
                						echo "<p>$description</p>";
                						echo "<p><img src='./uploads/shared_photos/$imgSrc' width='200em'></p>";
                						echo "<p> Comment: $comment</p>";
                						echo "<span>$date</span>";
                						echo "</div>";
            						}
        					}else{
        						echo "No activities for this yet";
        					}
        				?>
	
				</div>
				<div id='likes'>
					<h4> Likes </h4>
					<?php
	
        					$likesStmt = $conn->prepare("SELECT photo_id, like_date FROM likes 
        								WHERE user_id = ? ORDER BY like_date");
        					$likesStmt->bind_param("i", $userId);
        					$likesStmt->execute();
        					$likesResult = $likesStmt->get_result();
	
        					if ($likesResult->num_rows > 0) {
            						while ($likeRow = $likesResult->fetch_assoc()) {
                						$date = $likeRow["like_date"];
                						$photoId = $likeRow['photo_id'];
                						$stmt = $conn->prepare("SELECT filename,description FROM shared_photos WHERE photoId = ?");
                						$stmt -> bind_param('i',$photoId);
                						$stmt -> execute();
                						$stmt -> store_result();
                						$stmt -> bind_result($imgSrc,$description);
                						$stmt -> fetch();
                						echo "<div>";
                						echo "<p>$description</p>";
                						echo "<p><img src='./uploads/shared_photos/$imgSrc' width='150em'></p>";
                						echo "<span>$date</span>";
                						echo "</div>";
            						}
        					}else{
        						echo "No activities for this yet";
        					}
					?>
				</div>
				<div id='feedback'>
					<h4> Feedback </h4>
					<?php
	
        					$stmt = $conn->prepare("SELECT feedback_text, submitted_at FROM feedback 
        								WHERE user_id = ? ORDER BY submitted_at");
        					$stmt->bind_param("i", $userId);
        					$stmt->execute();
        					$result = $stmt->get_result();
	
        					if ($result->num_rows > 0) {
            						while ($row = $result->fetch_assoc()) {
                						$date = $row["submitted_at"];
                						$feedback = $row['feedback_text'];
                						echo "<div>";
                						echo "<p>$feedback</p>";
                						echo "<span>$date</span>";
                						echo "</div>";
            						}
        					}else{
        						echo "No activities for this yet";
        					}
        				?>
				</div>
				<div id='shared-photos'>
					<h4>Shared Photos </h4>
					<?php
		
        					$stmt = $conn->prepare("SELECT filename, description, upload_date 
        								FROM shared_photos WHERE uploader_id = ? 
        								ORDER BY upload_date");
        					$stmt->bind_param("i", $userId);
        					$stmt->execute();
        					$result = $stmt->get_result();
	
        					if ($result->num_rows > 0) {
            						while ($row = $result->fetch_assoc()) {
                						$date = $row["upload_date"];
                						$description = $row['description'];
                						$imgSrc = $row['filename'];
                						echo "<div>";
                						echo "<p>$description</p>";
                						echo "<p><img src='./uploads/shared_photos/$imgSrc' width='200em'></p>";
                						echo "<span>$date</span>";
                						echo "</div>";
            						}
        					}else{
        						echo "No activities for this yet";
        					}
        				?>
				</div>
			</section>
		</div>	
	</body>	
	<script>
		function editProfile(photoId){
        		var xhr = new XMLHttpRequest();
        		xhr.open('POST','like_photo.php');
        		xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
       			xhr.onload = function (){
       				if(xhr.status === 200){
       					var likeCount = parseInt(xhr.responseText);
       					document.getElementById('like-count-'+photoId).innerText = likeCount;
       				}
       			};
       			xhr.send('photo_id='+photoId);
        	};
        	
        	document.addEventListener('DOMContentLoaded', function() {
  const edit_picture_btn = document.getElementById('edit-picture-btn');
  const edit_profile_btn = document.getElementById('edit-profile-btn');
  const change_password_btn = document.getElementById('ch-passwd-btn');
  const container = document.getElementById('container');
  const closeButton = document.getElementById('closeButton');
  const cancelButton = document.getElementById('cancelButton');
  const container_contents = document.getElementById('container-contents');
  
  edit_picture_btn.addEventListener('click', function(event) {
    container.classList.remove('hidden');
    container_contents.innerHTML = `
    				<form action="update.php" method="post" enctype="multipart/form-data">
    					<label for="photo">Upload Photo:</label><br>
    					<input type="file" id="photo" name="photo"><br><br>
    					<input type="submit" value="Upload">
				</form>
    				`;
    event.stopPropagation();
  });
  
  change_password_btn.addEventListener('click', function(event) {
    container.classList.remove('hidden');
    container_contents.innerHTML = `
    				<form action="update.php" method="post" enctype="multipart/form-data">
    					<label for="old-pass">Old Password: </label><br>
					<input type="password" name="old-pass" id="old-pass" placeholder="Enter Old password" required/><br>
    					<label for="new-pass">New Password: </label><br>
					<input type="password" name="new-pass" id="new-pass" placeholder="Enter New password" required/><br>
					<label for="confirm-pass">Confirm Password: </label><br>
					<input type="password" name="confirm-pass" id="confirm-pass" placeholder="Confirm password" required/><br>
					<button type="submit">Submit</button>
				</form>
    				`;
    event.stopPropagation();
  });
  
  edit_profile_btn.addEventListener('click', function(event) {
    container.classList.remove('hidden');
    container_contents.innerHTML = `
    			<div class="register-container">
				<form action="./update.php" method="POST">
					<label for="name">Full Name: </label><br>
					<input type="text" name="name" id="name" value="<?php echo $name ;?>" required/><br>
					<label for="email">Email: </label><br>
					<input type="email" name="email" id="email" value="<?php echo $email ;?>" required><br>
					<label for="phone-number">Phone Number: </label><br>
					<input type="tel" name="phone-number" id="phone-number" value="<?php echo $phone_number ;?>" required/><br>
					<label for="dob">Date of Birth: </label><br>
					<input type="date" name="dob" id="dob" value="<?php echo $dob ;?>" required/><br>
					<p>Gender</p>
					<input type="radio" name="gender" id="male" <?php echo ($gender=="MALE")? "checked":"" ;?> value="male" />
					<label for="male" class="radio-gender">Male: </label><br>
					<input type="radio" name="gender" id="female" <?php echo ($gender=="FEMALE")? "checked":"" ;?>value="female" />
					<label for="female" class="radio-gender">Female: </label><br>
					<input type="radio" name="gender" id="other" <?php echo ($gender=="OTHER")? "checked":"" ;?> value="other" />
					<label for="other" class="radio-gender">Other: </label><br><br>
					<label for="bio">Bio: </label><br>
					<textarea class="bio" id="bio" name="bio" required><?php echo $bio ;?></textarea><br>
					<button type="submit">Submit</button>
				</form>
			</div>`;
    event.stopPropagation();
  });

  closeButton.addEventListener('click', function(event) {
    container.classList.add('hidden');
    event.stopPropagation();
  });

  cancelButton.addEventListener('click', function(event) {
    container.classList.add('hidden');
    event.stopPropagation();
  });


  document.addEventListener('click', function(event) {
    if (!container.contains(event.target)) {
      container.classList.add('hidden');
    }
  });
});

	</script>
</html>
