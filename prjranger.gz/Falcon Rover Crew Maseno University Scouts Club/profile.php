








<?php
	$path="/var/www/html/Falcon Rover Crew Maseno University Scouts Club/inc/";
	require_once $path."db.php";	
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" content="width=device-width ,initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <title> FRCMSU Profile page</title>
    <style>
        body {
            background: white;
            padding: 40px;
            font-size: 1.1em;
        }
        .main{
            margin: auto;
            box-shadow: 0px 4px 4px 0px gray;
            padding: 50px;
            background: #ddd;
            width: 60%;
            border-radius: 10px;
        }
        .user-informations{
            display: inline;
        }
        .user-informations td{
            text-align: left;
            padding: 5px 20px;
        
        }
        .user-informations td:nth-child(1){
            font-weight: bold;
        }
        .profile-pic{
            max-width: 10em;
            padding: 10px 30px;
            display:table;
            margin: auto;
        }
        
        .profile-actions {
        	display: table;
            	margin: 0 auto;
        }
        .profile-actions li{
            padding: 10px 10px;
            display: inline-block;
    	    text-align: justify;
    	    list-style: none;
        }
        
        .profile-actions li button{
            padding: 2px 0.5em;
            font-weight: bold;
        }
        .profile-actions li button:hover{
            cursor: pointer;
        }
        
        section {
        	border: 1px solid black;
        	margin: 40px 20px;
        	padding: 20px 40px;
        }
        
        .main-btn{
        	width: 80%;
        	height: 30px;
        	display: table;
        	margin: auto;
        }
        #map {
            height: 500px;
        }
        .hidden {
  		display: none;
	}

	#container {
  		position: absolute;
  		top: 50%;
  		left: 50%;
  		transform: translate(-50%, -50%);
  		background-color: #f0f0f0;
  		padding: 20px;
  		border: 1px solid #ccc;
  		min-width: 40%;
  		z-index: 5;
	}

	#innerContainer {
  		text-align: center;
	}

	#closeButton {
  		position: absolute;
  		top: 10px;
  		right: 10px;
  		background-color: transparent;
  		border: none;
  		cursor: pointer;
	}
	#container-contents{
		width:100%;
	}
	#innerContainer li button {
		background: #888;
		width: 80%;
		height: 35px;
		margin: 5px 0px;
		font-size: 1.2em;
		font-weight: bolder;
	}
	#innerContainer li button:hover{
		color: #333;
		background: white;
		cursor:pointer;
	}
	#innerContainer li {
        	list-style: none;
        	margin: auto;
        }
        
        @media (max-width: 750px){
        	.main{
            		margin: auto;
            		box-shadow: 0px 4px 4px 0px gray;
            		padding: 10px;
            		background: #ddd;
            		width: 100%;
            		border-radius: 10px;
        	}
        	
  		body{
            		padding: 0px;
            		font-size: 1.2em;
        	}
        	section {
        	border: 1px solid black;
        	margin: 0px;
        	padding: 20px 40px;
        	}
        }
	
    </style>
</head>

<body>
    <div class="main">
        <img src="./uploads/profile_photos/<?php echo $profile_picture; ?>" alt="profile-picture" class="profile-pic">
        <div>
            <table class="user-informations">
                <tr>
                    <td>Name: </td>
                    <td> <?php echo $username; ?></td>
                </tr>
                <tr>
                    <td>Email: </td>
                    <td> <?php echo $email; ?></td>
                </tr>
                <tr>
                    <td>Card No: </td>
                    <td><?php echo $card_number; ?></td>
                </tr>
                <tr>
                    <td>Rank: </td>
                    <td><?php echo $rank; ?></td>
                </tr>
                <tr>
                    <td>Bio: </td>
                    <td><?php echo $bio; ?></td>
                </tr>
            </table>

            <ul class="profile-actions">
                <a href="./account.php"><li><button><i class="fas fa-user-edit"></i> Account</button></li></a>
                <a href="./messages_interface.php"><li><button><i class="fas fa-envelope"></i> Message</button></li></a>
                <a href="./newsfeed.php"><li><button><i class="fas fa-newspaper"></i> News Feed</button></li></a>
                <a href="./photo_sharing.php"><li><button><i class="fas fa-camera"></i> Photos</button></li></a>
                <a href="./logout.php"><li><button><i class="fas fa-sign-out-alt"></i> Logout</button></li></a>
            </ul>
        </div>
        <?php
        	if ($role === "ADMIN" && $admin = TRUE){
    			echo '<button class="main-btn" id="main-btn" ><i class="fas fa-tools"></i>  ADMIN PANEL</button>';
    		}
    	?>
    	<div id="container" class="hidden">
  		<div id="innerContainer">
    			<button id="closeButton">X</button>
    			<div id="container-contents">
    			</div>
    			<button id="cancelButton">Cancel</button>
  		</div>
  	</div>

    <section>
        <h3>Quick Services</h3>
        <ul>
            <a href="#event-calendar"><li>Event Calendar</li></a>
            <a href="#gps-integration"><li>GPS Integration</li></a>
            <a href="#feedback-surveys"><li>Feedback and Surveys</li></a>
            <a href="#library"><li>Resource Library</li></a>
            <a href="#emergency"><li>Emergency Contacts</li></a>
            <a href="#social"><li>Share to other social pages</li></a>
        </ul>
    </section>
    <section id="event-calendar">
        <?php
    	 	require_once $path."event_calendar.php";
    	 ?>
    </section>
    <section id="gps-integration">
    	<?php
    	 	require_once $path."gps_integration.php";
    	 ?>
    </section>
    <section id="feedback-surveys">
    	<?php
    	 	require_once $path."feedback_surveys.php";
    	 ?>
    </section>
    <section id="library">
    	<?php
    	 	require_once $path."resource_library.php";
    	 ?>
    </section>
    <section id="emergency">
    	<?php
    	 	require_once $path."emergency_contacts.php";
    	 ?>
    </section>
    <section id="social">
    	<?php
    	 	require_once $path."social_media_integration.php";
    	 ?>
    </section>
    </div>
 </body>
 	<?php
		if ($role === "ADMIN" && $admin = TRUE){
			$admin_panel = "
				<div class='admin-container'>
					<ul class='admin-container-ul'>
						<a href='./photo_sharing.php'><li><button>Upload Photos</button></li></a>
						<a href='./newsfeed.php'><li><button>Manage Newsfeed</button></li></a>
						<a href='./surveys_management.php'><li><button>Manage surveys</button></li></a>
						<a href='./manage_events.php'><li><button>Manage Events</button></li></a>
						<a href='#library'><li><button>Upload Resource</button></li></a>
						<a href='./admin_panel.php?action=feedback'><li><button>Check Feedbacks</button></li></a>
						<a href='./admin_panel.php?action=rsvp'><li><button>Check Submitted RSVP</button></li></a>
						<a href='./admin_panel.php?action=manage_users'><li><button>Manage Users</button></li></a>
					</ul>
				</div>";
    			echo "
    				<script>
   					document.addEventListener('DOMContentLoaded', function() {
   						const main_btn = document.getElementById('main-btn');
   						const container = document.getElementById('container');
   						const closeButton = document.getElementById('closeButton');
   						const cancelButton = document.getElementById('cancelButton');
   						const container_contents = document.getElementById('container-contents');
    
    						main_btn.addEventListener('click', function(event) {
    							container.classList.remove('hidden');
    							container_contents.innerHTML = `
    								$admin_panel	
    									`;
    							event.stopPropagation();
  						});		
    		
    						closeButton.addEventListener('click', function(event) {
    							container.classList.add('hidden');
    							event.stopPropagation();
  						});

    						cancelButton.addEventListener('click', function(event) {
    							container.classList.add('hidden');
    							event.stopPropagation();
  						});


    						document.addEventListener('click', function(event) {
    							if (!container.contains(event.target)) {
      								container.classList.add('hidden');
    							}
  						});
					});
				</script>
    			";
    		}
    	?>
</html>
