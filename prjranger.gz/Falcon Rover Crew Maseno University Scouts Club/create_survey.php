





<?php
	$path="/var/www/html/Falcon Rover Crew Maseno University Scouts Club/";
?>

<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $surveyTitle = $_POST['survey-title'];
    $questions = $_POST['questions'];
    $questionTypes = $_POST['question-types'];
    $options = $_POST['options'];

    // Create HTML content for the survey
    $htmlContent = "<!DOCTYPE html>\n";
    $htmlContent .= "<html lang='en'>\n";
    $htmlContent .= "<head>\n";
    $htmlContent .= "<meta charset='UTF-8'>\n";
    $htmlContent .= "<meta name='viewport' content='width=device-width, initial-scale=1.0'>\n";
    $htmlContent .= "<title>$surveyTitle</title>\n";
    $htmlContent .= "</head>\n";
    $htmlContent .= "<body>\n";
    $htmlContent .= "<h3>$surveyTitle</h3>\n";
    $htmlContent .= "<form action='submit_survey.php' method='post'>\n";

    
    for ($i = 0; $i < count($questions); $i++) {
        $question = $questions[$i];
        $questionType = $questionTypes[$i];
        $htmlContent .= "<h4>$question</h4>\n";
        
        if(isset($options[$i]) && is_array($options[$i]) && !empty($options[$i])){
        	if ($questionType === 'checkbox') {
        		foreach ($options[$i] as $option) {
                		$htmlContent .= "<label><input type='checkbox' name='question-$i' value='$option'>$option</label><br>\n";
                		
            		}
            	} elseif ($questionType === 'radio') {
            		foreach ($options[$i] as $option) {
                		$htmlContent .= "<label><input type='radio' name='question-$i' value='$option'>$option</label><br>\n";
            		}
        	}
        }
        $htmlContent .= "<br>\n";
    }

    $htmlContent .= "<input type='submit' value='Submit'>\n";
    $htmlContent .= "</form>\n";
    $htmlContent .= "</body>\n";
    $htmlContent .= "</html>";
    
    // Save HTML content to a file in the /surveys directory
    $filepath = $path.'surveys/'; // Generate a unique filename
    $filename = $surveyTitle.'.html';
    if(file_exists($filepath.$filename)){
	echo "A survey with similar title already exists";
	exit();
    }
    file_put_contents($filepath.$filename, $htmlContent);
    // Redirect to the newly created survey page
    header("Location: surveys/$filename");
    exit;
}
?>
