<?php
	$path="/var/www/html/Falcon Rover Crew Maseno University Scouts Club/inc/";
	require_once $path."db.php";

	$surveyFiles = glob('surveys/*');
	if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_survey'])) {
    		$surveyToDelete = $_POST['delete_survey'];
    		if (in_array($surveyToDelete, $surveyFiles)) {
        		unlink($surveyToDelete);
        		header("Location: $_SERVER[PHP_SELF]");
        		exit;
    	}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Survey Management</title>
</head>
<body>
    <h2>Survey Management</h2>

    <h3>Available Surveys:</h3>
    <ul>
        <?php
        foreach ($surveyFiles as $surveyFile) {
            $surveyName = pathinfo($surveyFile,PATHINFO_FILENAME);
            echo "<li><a href='$surveyFile'>$surveyName</a> 
            <form action='' method='post' style='display:inline;'>
                <input type='hidden' name='delete_survey' value='$surveyFile'>
                <button type='submit'>Delete</button>
            </form></li>";
        }
        ?>
    </ul>

    <h3>Upload New Survey:</h3>
    <form action="upload_survey.php" method="post" enctype="multipart/form-data">
        <input type="file" name="survey_file" required accept=".html">
        <button type="submit">Upload</button>
    </form>
    <h3> Create a New Survey: </h3>
    <?php require_once $path."add_survey_questions.php";?>
</body>
</html>
