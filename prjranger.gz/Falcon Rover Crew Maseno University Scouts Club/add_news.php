<?php 

$dbHost = "localhost";
$dbUser = "blvckai";
$dbPassword = "blvck953@#";
$dbName = "phplogin";
$conn = new mysqli($dbHost, $dbUser, $dbPassword, $dbName);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['title']) && isset($_POST['content']) && !empty($_POST['title']) && !empty($_POST['content'])){
	$title = htmlspecialchars(trim($_POST['title']), ENT_QUOTES,'UTF-8');
	$content = htmlspecialchars(trim($_POST['content']), ENT_QUOTES,'UTF-8');
	$userId = htmlspecialchars(trim($_POST['user-id']), ENT_QUOTES,'UTF-8');
	
	echo $userId;
	if($stmt = $conn -> prepare("INSERT INTO news (uploader_id, title, content) VALUES (?,?,?)")){
		$stmt -> bind_param('iss',$userId,$title,$content);
		$stmt -> execute();
		if ($stmt->connect_error) {
    			die("Connection failed: " . $stmt->connect_error);
		}else{
			//echo "News Added successfully";
			header("Location: ./newsfeed.php");
			$stmt -> close();
			$conn->close();
			exit();
		}	
	}else{
		die("Error occurred");
	}
	$stmt -> close();
}
$conn->close();
?>
