<?php
	session_start();
	if (!isset($_SESSION['loggedin'])) {
		header('Location: ./login.php');
		exit;
	}
	
	$DATABASE_HOST = 'localhost';
	$DATABASE_USER = 'blvckai';
	$DATABASE_PASS = 'blvck953@#';
	$DATABASE_NAME = 'phplogin';
	$conn = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
	if (mysqli_connect_errno()) {
		exit('Failed to connect to MySQL: ' . mysqli_connect_error());
	}
	
	if(htmlspecialchars(trim($_SESSION['loggedin']),ENT_QUOTES,'UTF-8')){
		$name = htmlspecialchars(trim($_SESSION['name']),ENT_QUOTES,'UTF-8');
		$id = htmlspecialchars(trim($_SESSION['id']),ENT_QUOTES,'UTF-8');
		if ($stmt = $conn -> prepare("SELECT userId, name, email, card_number, rank, 
		  profile_picture, bio, role FROM users WHERE name = ? AND userId = ? ")){
		  
			$stmt -> bind_param('ss',$name,$id);
			$stmt -> execute();
			$stmt -> store_result();
			if($stmt->num_rows !== 1){
				header('Location: ./login.php');
				exit;
			}else{
				$stmt -> bind_result($userId, $username, $email, $card_number, $rank, $profile_picture, $bio, $role );
				$stmt -> fetch();
				$path="/var/www/html/Falcon Rover Crew Maseno University Scouts Club/";
				if($role === "ADMIN"){
					require_once $path."adm.php";
				}
			}
		}
	}
	
?>


<?php
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
    		if (isset($_FILES["photo"])){
    			if($_FILES["photo"]["error"] == 0) {
    				update_profile_pic($conn, $FILES, $userId);
    			} else {
        			echo "No file uploaded or an error occurred.";
    			}
    		}elseif(isset($_POST['old-pass'], $_POST['new-pass'], $_POST['confirm-pass'])){
    			if(!empty($_POST['old-pass']) && !empty($_POST['new-pass']) && !empty($_POST['confirm-pass'])){
    				 $old_pass = htmlspecialchars(trim($_POST['old-pass']), ENT_QUOTES,'UTF-8');
    				 $new_pass = htmlspecialchars(trim($_POST['new-pass']), ENT_QUOTES,'UTF-8');
    				 $confirm_pass = htmlspecialchars(trim($_POST['confirm-pass']), ENT_QUOTES,'UTF-8');
    				 
    				 if($new_pass !== $confirm_pass){
    				 	echo "Password not equal. ";
    				 	exit();
    				 }
    				 update_password($conn, $old_pass, $new_pass, $userId);
    				 
    				 
    			}else{
    				echo "Fill out all the input fields and try again.";
    			}
    		}elseif(isset($_POST['name'],$_POST['email'],$_POST['phone-number'],
    		 $_POST['dob'],$_POST['gender'],$_POST['bio'])){
    		 
    			if(!empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['phone-number']) && 
    		 	!empty($_POST['dob']) && !empty($_POST['gender']) && !empty($_POST['bio'])){
    		 	
    				$name = htmlspecialchars(trim($_POST['name']), ENT_QUOTES,'UTF-8');
    				$email = htmlspecialchars(trim($_POST['email']), ENT_QUOTES,'UTF-8');
    				$phone_number = htmlspecialchars(trim($_POST['phone-number']), ENT_QUOTES,'UTF-8');
    				$dob  = htmlspecialchars(trim($_POST['dob']), ENT_QUOTES,'UTF-8');
    				$gender = htmlspecialchars(trim($_POST['gender']), ENT_QUOTES,'UTF-8');
    				$bio = htmlspecialchars(trim($_POST['bio']), ENT_QUOTES,'UTF-8');
    				
    				update_user_info ($conn, $name, $email, $phone_number, $dob, $gender, $bio, $userId );
    				
    			}else{
    				echo "Fill out all input fields and try again";
    			}
    		}else{
    			header("");
    		}
	}


	function update_password($conn, $old_password,$new_password,$user_id){
		if($stmt = $conn -> prepare("SELECT password FROM users WHERE userId = ?")){
			$stmt -> bind_param('i',$user_id);
			$stmt -> execute();
			$stmt -> bind_result($original_password);
			$stmt -> fetch();
			$stmt -> close();
			
			if(password_verify($old_password,$original_password)){
				if($stmt = $conn -> prepare("UPDATE users SET password = ? WHERE userId = ?")){
					$password = password_hash($new_password, PASSWORD_DEFAULT);
					$stmt -> bind_param('si', $password, $user_id);
					$stmt -> execute();
					$stmt -> close();
					echo "Password updated successfully";
				}else{
					echo "An error occured while processing. Try again";
				}
			}else{
				echo "Incorrect password. Try again";
			}
		}
	}
	
	function update_profile_pic ($conn, $FILES, $userId){
        	$uploadDir = "uploads/profile_photos/";
        	if(!is_dir($uploadDir)){
        		if(!mkdir($uploadDir,0777,true)){
        			echo "Error occured while uploading folder";
        		}
        	}

        	$filename = uniqid()."_".basename($_FILES["photo"]["name"]);
        	$targetFilePath = $uploadDir.$filename;

        	if ($_FILES["photo"]["size"] > 10 * 1024 * 1024) {
            		echo "Sorry, your file is too large.";
            		exit;
        	}

        	$allowedFormats = array("jpg", "jpeg", "png", "gif");
        	$fileFormat = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));
        	if (!in_array($fileFormat, $allowedFormats)) {
            		echo "Sorry, only JPG, JPEG, PNG, and GIF files are allowed.";
            		exit;
        	}

        	if (move_uploaded_file($_FILES["photo"]["tmp_name"], $targetFilePath)) {
            		$description = $_POST["description"];
            		$uploaderId = $userId;

            		$stmt = $conn->prepare("UPDATE users SET profile_picture = ? WHERE userId = ? ");
            		$stmt->bind_param("si", $filename,$userId);

            		if ($stmt->execute()) {
                		echo "File uploaded successfully.";
            		} else {
                		echo "Error: " . $stmt->error;
            		}
            		$stmt->close();
            		$conn->close();
        	} else {
            		echo "Sorry, there was an error uploading your file.";
        	}

	}
	function update_user_info ($conn, $name, $email, $phone_number, $dob, $gender, $bio, $userId ){
		if($stmt = $conn -> prepare("UPDATE users 
					SET name = ? , email = ? , phone_number = ? , DOB = ? , gender = ? , bio = ? 
					WHERE userId = ?")) {
					
			$stmt -> bind_param('ssssssi', $name, $email, $phone_number, $dob, $gender, $bio, $userId );
			if($stmt -> execute()){
				echo "Updated successfully";
			}else{
				echo "Error occurred while processing, try again";
			}
		}
	}
	
	$conn -> close();	
	
?>
