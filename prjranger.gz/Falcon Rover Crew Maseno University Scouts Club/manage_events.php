








<?php
	$path="/var/www/html/Falcon Rover Crew Maseno University Scouts Club/inc/";
	require_once $path."db.php";
	
	
	if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['userId']) && isset($_POST['title']) && isset($_POST['venue']) && isset($_POST['date']) && isset($_POST['time'])){
		$userId = htmlspecialchars(trim($_POST['userId']), ENT_QUOTES,'UTF-8');
		$title = htmlspecialchars(trim($_POST['title']), ENT_QUOTES,'UTF-8');
		$venue = htmlspecialchars(trim($_POST['venue']), ENT_QUOTES,'UTF-8');
		$date = htmlspecialchars(trim($_POST['date']), ENT_QUOTES,'UTF-8');
		$time = htmlspecialchars(trim($_POST['time']), ENT_QUOTES,'UTF-8');
			
		if(!empty($userId) && !empty($title) && !empty($venue) && !empty($date) && !empty($time)){
			if ($stmt = $conn -> prepare("INSERT INTO events (uploader_id, event_title, event_venue,
							 event_date, scheduled_time) VALUES (?,?,?,?,?)")){
				$stmt -> bind_param('issss',$userId,$title,$venue,$date,$time);
				$stmt -> execute();
				echo "Submitted successfully";
			}else{
				echo "Error occured please try again";
			}
		}else{
			echo "Fill all the forms and try again";
		}
	}
	
	function delete_event($conn, $eventId){
		if ($stmt = $conn -> prepare("DELETE FROM events WHERE eventId = ?")){
				$stmt -> bind_param('i',$eventId);
				$stmt -> execute();
				echo "Submitted successfully";
		}
	}
	
	if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete']) && !empty($_POST['delete'])){
		$deleteId = htmlspecialchars(trim($_POST['delete']), ENT_QUOTES,'UTF-8');
		delete_event($conn,$deleteId);
	}
	
	if($stmt = $conn -> prepare("SELECT eventId,event_date,event_title,scheduled_time,event_venue FROM events")){
		$stmt -> execute();
		$eventsResult = $stmt->get_result();
		$events = array();
		if ($eventsResult->num_rows > 0) {
            		while ($eventsRow = $eventsResult->fetch_assoc()) {
            			$event = array(
            			"eventId" => $eventsRow['eventId'],"event_date" => $eventsRow['event_date'],
            			"event_title" => $eventsRow['event_title'],"scheduled_time" => $eventsRow['scheduled_time'],
            			"event_venue" => $eventsRow['event_venue']
            			);
            			$events[] = $event;	
            		} 
            	}
	
	}

?>


<!DOCTYPE html>
<html lang="en">
	<head>
		
	</head>
	<body>		
			<h3> Delete Events</h3>
			<ul>
			<?php
				foreach ($events as $event) {
    					echo "<li>{$event['event_date']} - {$event['event_title']} @ {$event['scheduled_time']}, {$event['event_venue']}</li>";
    					echo "<form action='./manage_events.php' method='POST'>";
    					echo "<input type='number' name='delete' value='{$event['eventId']}' hidden>";
    					echo "<button type='submit'>Delete</button>";
    					echo "</form>";
				}
			?>
			</ul>
			<hr>
			
			<h3> Add Events</h3>
			<form action="./manage_events.php" method="POST">
				<input type="number" name="userId" id="user-id" value="1" hidden required><br><br>
				<label for="title">Title: </label><br><br>
				<input type="text" name="title" id="title" placeholder="Enter the title for the event" required autofocus/><br><br>
				<label for="venue">Venue: </label><br><br>
				<input type="text" name="venue" id="venue" placeholder="Enter venue for the event" required/><br><br>
				<label for="date">Date: </label><br><br>
				<input type="date" name="date" id="date" placeholder="Date for the for the event" required/><br><br>
				<label for="time">Time: </label><br><br>
				<input type="time" name="time" id="time" placeholder="Enter the time for the event" required/><br><br>
				<button type="submit">Submit</button>
			</form>
			
	</body>
</html>
